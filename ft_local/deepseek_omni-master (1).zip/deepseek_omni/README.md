# 参考 

具体看 readme.md

模型来源：https://git.tencent.com/lxmxiang/deepseek_omni_deploy