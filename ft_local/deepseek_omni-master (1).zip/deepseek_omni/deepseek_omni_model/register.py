# Copyright (c) 2025, Alibaba Cloud and its affiliates;
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# Registration function for explicit use
def register_deepseek_omni():
    """Register FunAudioChat classes with AutoConfig and AutoModel."""
    from transformers import AutoConfig, AutoModelForSeq2SeqLM, AutoProcessor
    from .configuration_deepseek_omni import Qwen3OmniTextConfig, Qwen3OmniMoeAudioEncoderConfig
    from .modeling_deepseek_omni import Qwen3OmniForConditionalGeneration
    from .processor_deepseek_omni import CustomQwen3OmniAudioProcessor
    
    # Register configurations
    AutoConfig.register("qwen3_omni_text", Qwen3OmniTextConfig)
    AutoConfig.register("qwen3_omni_moe_audio_encoder", Qwen3OmniMoeAudioEncoderConfig)
    # AutoConfig.register("qwen3_tts_talker", Qwen3TTSTalkerConfig)             # 加talker使用
    
    # Register processor
    AutoProcessor.register(Qwen3OmniTextConfig, CustomQwen3OmniAudioProcessor)
    
    # Register model
    AutoModelForSeq2SeqLM.register(Qwen3OmniTextConfig, Qwen3OmniForConditionalGeneration)