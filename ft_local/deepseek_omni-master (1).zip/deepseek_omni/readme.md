# DeepSeek Omni Deploy

基于 Hugging Face Transformers 的 Qwen3-Omni 多模态模型推理部署工具，支持**音频理解**（ASR / 语音对话）与**语音合成**（TTS / Talker）。

---

## 项目结构

```
deepseek_omni_deploy/
├── readme.md                       # 本文档
├── requirements.txt                # Python 依赖清单
├── test_deepseek_omni.py           # 推理示例脚本
├── deepseek_omni_model/            # 模型核心模块
│   ├── __init__.py
│   ├── register.py                 # 向 Transformers Auto* 注册自定义类
│   ├── configuration_deepseek_omni.py  # 模型配置（Thinker / Talker / AudioEncoder）
│   ├── modeling_deepseek_omni.py       # 模型实现（音频编码器、Thinker LLM、Talker 语音合成）
│   └── processor_deepseek_omni.py      # 音频预处理器（Whisper 特征提取 + Tokenizer）
└── qwen3_omni_tokenizer/           # TTS 语音编解码器（离散 token ↔ 波形）
    ├── __init__.py
    ├── qwen3_omni_tokenizer.py         # 编解码高层 API（encode / decode）
    ├── configuration_qwen3_omni_tokenizer_v2.py  # Tokenizer v2 配置
    ├── modeling_qwen3_omni_tokenizer_v2.py       # Tokenizer v2 模型实现
    └── vq/
        ├── core_vq.py                  # 向量量化（VQ）模块
        └── whisper_encoder.py          # Whisper 风格 Mel 编码器
```

### 核心模块说明

| 模块 | 作用 |
|------|------|
| `deepseek_omni_model` | 完整的 Qwen3-Omni 推理栈：**音频编码器**提取音频特征 → **Thinker**（大语言模型）生成文本回复 → **Talker**（可选）生成离散语音 token |
| `qwen3_omni_tokenizer` | 将 Talker 输出的离散语音 token 解码为可播放的 WAV 波形（12Hz / 25Hz 码本） |

---

## 环境准备

### 1. 创建 Conda 环境

```bash
conda create -n omni_deploy python=3.11 -y
conda activate omni_deploy
```

### 2. 安装 PyTorch（CUDA 12.8）

```bash
pip install torch==2.8.0 torchvision==0.23.0 torchaudio==2.8.0 --index-url https://download.pytorch.org/whl/cu128
```

> 如果你的 CUDA 版本不是 12.8，请前往 [PyTorch 官方](https://pytorch.org/get-started/locally/) 选择对应的安装命令。

### 3. 安装 Flash Attention 2

```bash
pip install flash_attn==2.8.3
```

> Flash Attention 需要与 GPU 架构兼容（Ampere / Hopper 及以上），安装时需要编译，请确保系统已安装 CUDA Toolkit 和 C++ 编译器。若安装失败，可在加载模型时将 `attn_implementation` 改为 `"sdpa"` 或 `"eager"`。

### 4. 安装其他依赖

```bash
pip install transformers==4.57.6 librosa qwen_omni_utils accelerate soundfile einops audioread numpy
```

或使用 `requirements.txt` 一键安装：

```bash
pip install -r requirements.txt
```

### 5. 准备模型权重

推理需要两组权重：

| 权重 | 用途 | 说明 |
|------|------|------|
| **主模型（Thinker + Talker）** | 文本理解 + 语音合成 | 目录下需包含 `config.json`、模型权重文件、`spk_dict.pt`（说话人嵌入字典） |
| **TTS Tokenizer（12Hz）** | 语音 token → WAV 波形 | 例如 `Qwen3-TTS-Tokenizer-12Hz` |

---

## 模型推理

### 快速开始

#### 第一步：修改路径配置

编辑 `test_deepseek_omni.py`，修改以下变量为你的实际路径：

```python
# GPU 选择（根据你的机器调整）
os.environ['CUDA_VISIBLE_DEVICES'] = "0,1"

# 主模型路径
MODEL_PATH = "/path/to/your/model/checkpoint"

# TTS Tokenizer 路径（用于语音输出）
tokenizer_model_path = "/path/to/Qwen3-TTS-Tokenizer-12Hz"
```

#### 第二步：构建对话消息

模型接受**多轮对话**格式的输入，支持纯文本和音频混合：

```python
messages = [
    # 系统提示词
    {
        "role": "<｜System｜>",
        "content": "你是一个有用的AI助手。"
    },
    # 纯文本用户输入
    {
        "role": "<｜User｜>",
        "content": "你好，请介绍一下你自己。"
    },
    # 助手回复
    {
        "role": "<｜Assistant｜>",
        "content": "<think>\n\n</think>\n\n你好！我是AI助手。<｜end▁of▁sentence｜>"
    },
    # 带音频的用户输入
    {
        "role": "<｜User｜>",
        "content": [
            {"type": "text", "text": "<audio>"},
            {"type": "audio", "audio": "/path/to/audio.wav"},
        ]
    },
]
```

> **注意**：音频输入需在 `text` 中用 `<audio>` 占位符标记音频位置，并在 `content` 列表中提供对应的音频文件路径。

#### 第三步：运行推理

```bash
python test_deepseek_omni.py
```

推理过程：
1. 加载模型和处理器
2. 预处理对话（模板化文本 + 提取音频特征）
3. 模型生成文本回复（Thinker）
4. 模型生成语音 token（Talker，可选）
5. TTS Tokenizer 将语音 token 解码为 WAV 文件（`sing_.wav`，采样率 24kHz）

---

### 推理流程详解

```
输入音频 (.wav)
     │
     ▼
┌─────────────────────────────────────┐
│  CustomQwen3OmniAudioProcessor      │
│  · apply_chat_template → 文本模板化  │
│  · Whisper 特征提取 → input_features │
│  · Tokenizer 编码 → input_ids       │
└──────────────┬──────────────────────┘
               │
               ▼
┌─────────────────────────────────────┐
│  Qwen3OmniForConditionalGeneration  │
│                                     │
│  ┌──────────────┐                   │
│  │ Audio Encoder │ → 音频表示       │
│  └──────┬───────┘                   │
│         ▼                           │
│  ┌──────────────┐                   │
│  │   Thinker    │ → 文本 tokens     │ ← 文本回复
│  │  (LLM 主体)  │                   │
│  └──────┬───────┘                   │
│         ▼                           │
│  ┌──────────────┐                   │
│  │   Talker     │ → 语音 codes      │ ← 离散语音 token（可选）
│  └──────────────┘                   │
└──────────────┬──────────────────────┘
               │
               ▼
┌─────────────────────────────────────┐
│  Qwen3OmniTokenizer (12Hz)         │
│  语音 codes → WAV 波形 (24kHz)      │
└─────────────────────────────────────┘
               │
               ▼
         输出: sing_.wav
```

---

### 关键参数说明

#### `model.generate()` 参数

**Thinker（文本生成）参数：**

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `thinker_max_new_tokens` | 1024 | 文本生成的最大 token 数 |
| `thinker_do_sample` | True | 是否使用采样（False 则为贪心解码） |
| `thinker_repetition_penalty` | 1.2 | 重复惩罚系数 |

**Talker（语音合成）参数：**

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `return_audio` | True | 是否生成语音输出 |
| `speaker` | `"amei"` | 说话人名称（需存在于 `spk_dict.pt` 中） |
| `talker_max_new_tokens` | 200 | 语音 token 最大生成数 |
| `talker_do_sample` | True | 是否使用采样 |
| `talker_temperature` | 0.9 | 采样温度 |
| `talker_top_k` | 50 | Top-K 采样 |
| `talker_top_p` | 1.0 | Top-P (Nucleus) 采样 |
| `talker_repetition_penalty` | 1.05 | 重复惩罚系数 |

#### 控制开关

| 变量 | 说明 |
|------|------|
| `RETURN_AUDIO = True` | 设为 `False` 可跳过语音合成，仅输出文本 |
| `CUDA_VISIBLE_DEVICES` | 控制使用哪些 GPU，多卡时模型会自动分布（`device_map="auto"`） |

---

## 仅文本推理（不生成语音）

如果只需要文本回复，不需要语音输出，将 `RETURN_AUDIO` 设为 `False`：

```python
RETURN_AUDIO = False
```

此时不需要加载 `Qwen3OmniTokenizer`，推理速度更快。

---

## 常见问题

**Q: 出现 `ValueError: spk_dict.pt not found`**
A: 确保主模型目录下包含 `spk_dict.pt` 文件，该文件存储了说话人嵌入向量。

**Q: Flash Attention 安装失败**
A: 可以跳过 Flash Attention，将模型加载代码中的 `attn_implementation` 参数改为 `"sdpa"`：
```python
model = Qwen3OmniForConditionalGeneration.from_pretrained(
    MODEL_PATH,
    dtype='auto',
    attn_implementation='sdpa',   # 替代 flash_attention_2
    device_map="auto"
)
```

**Q: 如何更换说话人音色？**
A: 修改 `generate()` 中的 `speaker` 参数，可选值取决于 `spk_dict.pt` 中包含的说话人列表。

**Q: 显存不足（OOM）**
A: 尝试以下方案：
- 使用更多 GPU（调整 `CUDA_VISIBLE_DEVICES`）
- 减小 `thinker_max_new_tokens` 和 `talker_max_new_tokens`
- 设置 `RETURN_AUDIO = False` 关闭语音合成以节省显存
