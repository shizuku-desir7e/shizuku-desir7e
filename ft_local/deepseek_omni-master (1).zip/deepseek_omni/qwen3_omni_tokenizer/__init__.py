"""
qwen_tts: Qwen-Omni package.
"""

from .qwen3_omni_tokenizer import Qwen3OmniTokenizer

__all__ = ["__version__"]