# 基于 vllm 的 multimodal audio 模型部署

1. 模型代码来自：https://git.woa.com/jingyulli/LLaMA-Factory/tree/master；
2. 框架当前固定为 vllm==v0.9.2,可参考代码分支：https://github.com/vllm-project/vllm/tree/v0.9.2
3. 当前支持 MM_ckpt/checkpoints/deepseek-32B-v20-llama/ 模型权重的加载

启动方式，在容器内执行 `/opt/start.sh` 脚本，启动 8 卡并行推理服务。

## 1. 当前 vllm 部署方式

单卡部署场景命令：

单卡v0 版本部署
```shell
VLLM_USE_V1=0 \
vllm serve /models \
    --host ${POD_IP} \
    --port 8081 \
    --chat-template /opt/template_customqwen2audio.jinja \
    --chat-template-content-format openai \
    --quantization fp8 \
    --enable-prefix-caching \
    --max-model-len 8192
```

单卡v1 版本部署
```shell
VLLM_USE_V1=1 \
vllm serve /models \
    --host ${POD_IP} \
    --port 8081 \
    --chat-template /opt/template_customqwen2audio.jinja \
    --chat-template-content-format openai \
    --quantization fp8 \
    --enable-prefix-caching \
    --max-model-len 8192
```

单机 8 卡部署场景：

```shell
GLOO_SOCKET_IFNAME=bond1 \
NCCL_SOCKET_IFNAME=bond1 \
NCCL_IB_DISABLE=0 \
NCCL_IB_HCA=mlx5_bond_1,mlx5_bond_2,mlx5_bond_3,mlx5_bond_4,mlx5_bond_5,mlx5_bond_6,mlx5_bond_7,mlx5_bond_8 \
VLLM_USE_V1=0 \
vllm serve /models \
    --host ${POD_IP} \
    --port 8081 \
    --chat-template /opt/template_customqwen2audio.jinja \
    --chat-template-content-format openai \
    --tensor-parallel-size 8 \
    --quantization fp8 \
    --enable-prefix-caching \
    --max-model-len 8192
```

### Qwen3 Omni 部署

单卡 Qwen3 Omni 部署命令：

```shell
VLLM_USE_V1=1 \
vllm serve /qwen3Omni \
    --host ${POD_IP} \
    --port 8081 \
    --chat-template /opt/chat_template_qwen3_omni.jinja \
    --chat-template-content-format openai \
    --quantization fp8 \
    --enable-prefix-caching \
    --max-model-len 8192 \
    --trust-remote-code
```

### Qwen3 Omni 测试

运行 Qwen3 Omni 压力测试：

```shell
# 音频分析测试（单请求）
python3 test/test_qwen25_omni_text_online_serving_stress_test.py \
    --host ${POD_IP} \
    --port 8081 \
    --model /qwen3Omni \
    --test-type concurrent-analysis \
    --requests 1 \
    --concurrent-levels "1" \
    --analysis-test-types "multimodal" \
    --max-response-time 3.0
```

**测试前准备**：
- 确保音频文件位于 `test/result.wav`
- 测试脚本会自动使用该音频文件进行多模态测试

## 2. vllm 优化的实现方式

之前尝试了直接将模型代码放在 vllm 代码库中编译安装，会有部分 cuda 库的问题，所以当前采用直接安装 vllm==v0.9.2 版本，然后将我们自定义模型和注册部分代码直接拷贝到 `/usr/local/lib/python3.10/dist-packages/vllm/` 安装目录之下。

v0.9.2 的 vllm 支持了多模态的 audio 输入输出接口，支持了 openai 的 input_audio 接口模式，所以采用当前版本 vllm，并新增注册了我们自定义的 `src/patch/vllm/model_executor/models/custom_qwen2_audio.py` 到 vllm 的模型注册文件夹中。这里按照 vllm 的自定义模型和多模态模型要求开发了指定的接口，并多次测试了输入输出与原 Transformers 库的对比。具体可以参考模型代码。

另外需要改动 `src/patch/LLaMA-Factory/src/llamafactory/model/speech_encoder/custom_processor.py` 中的接口，统一 `FireASRAudioProcessor` 类的 `__call__`函数的入参支持 `audio` 和 `audios` 输入。

对于当前自定义模型的 template，按照最新的 v20 版本中的 template，给 vllm 框架新增了一个定制的 `template_customqwen2audio.jinja` 模板。

保持当前 vllm 推理接口与原先的 fastapi 服务的 openai 接口完全一致。


## 3. TODO

1. vllm V1 的推理支持；
2. 在 vllm V1 推理支持后测试整体的时延和吞吐，结合 sglang 社区进展考虑是否移植 sglang 框架；
3. 其他优化方式的探索。

## 4. Docker 构建方式

### 方法一：vLLM 0.9.2 版本构建

使用 `dockerfile` 构建 vLLM 0.9.2 版本：

```bash
# 构建 vLLM 0.9.2 版本
docker build -t mirrors.tencent.com/tencent_ieg_ultron_us/webui:vllm_0.9.2_v0.0.1 -f ./docker/dockerfile .

```

### 方法二：vLLM 0.10.2 版本构建

使用 `dockerfile_vllm0102` 构建 vLLM 0.10.2 版本：

```bash
# 构建 vLLM 0.10.2 版本
docker build -t mirrors.tencent.com/tencent_ieg_ultron_us/webui:vllm_0.10.2_v0.0.1 -f ./docker/dockerfile_vllm0102 .

```

### 版本选择说明

- **vLLM 0.9.2**: 使用 `dockerfile`，基于 `mirrors.tencent.com/ultron/tts/tritonserver-base:cu126-torch270`
- **vLLM 0.10.2**: 使用 `dockerfile_vllm0102`，基于 `mirrors.tencent.com/tencent_ieg_ultron_us/webui:vllm_0.10.2`


## 5. 实测对比

下面加了 30 条预热请求，每次测试前重启服务清理缓存



| 模型类型 | tp卡数 | 并发数 | 测试方式 | QPS | 平均响应(秒) | P95(秒) | P99(秒) | 成功率(%) | 超时率(%) | 平均Prompt | 平均Completion | 平均Total | 测试框架 |测试数据 |
|--------|--------|--------|--------|-----|------------|--------|---------|---------|----------|------------|------------|------------|------------|------------|
| text-llm | 8 | 1     | remote completions | 3.70 | 0.270 | 0.321 | 0.344 |  100.0  |  0.0 | 2738.76 | 13.12 | 2751.88 |  sglang-0.5.1 |mm_test_dev1k_4server |
| text-llm | 8 | 2     | remote completions | 6.21 | 0.322 | 0.390 | 0.421 |  100.0  |  0.0 | 2738.76 | 13.04 | 2751.80 |  sglang-0.5.1 |mm_test_dev1k_4server |
| text-llm | 8 | 4     | remote completions | 9.81 | 0.408 | 0.506 | 0.537 |  100.0  |  0.0 | 2738.76 | 13.16 | 2751.92 |  sglang-0.5.1 |mm_test_dev1k_4server |
| text-llm | 8 | 8     | remote completions | 13.49 |  0.592 | 0.766 | 0.888 |  100.0  |  0.0 | 2738.76 | 12.92 | 2751.68 |  sglang-0.5.1 |mm_test_dev1k_4server |
| text-llm | 8 | 16     | remote completions | 15.99 | 0.995 | 1.416 | 1.737 |  100.0  |  0.0 | 2738.76 | 13.07 | 2751.83 |  sglang-0.5.1 |mm_test_dev1k_4server |
| text-llm | 8 | 32     | remote completions | 17.74 | 1.796 |  2.615 | 2.895 |  100.0  | 0.9 | 2738.76 | 13.04 | 2751.80 |  sglang-0.5.1 |mm_test_dev1k_4server |
|--|--|--|--|--|--|--|--|--|--|--|--|--|--|--|
| multimodel-llm | 8 |  1     | remote chat/completions | 2.72 | 0.367 | 0.467 | 0.520 |  100.0  |  0.0  | 2774.30 | 13.77 | 2788.06 | vllm_0.10.2 |  mm_test_dev1k_4server |
| multimodel-llm | 8 |  2     | remote chat/completions | 4.74 | 0.422 | 0.537 | 0.627 |  100.0  |  0.0  | 2774.30 | 13.80 | 2788.10 | vllm_0.10.2 |  mm_test_dev1k_4server |
| multimodel-llm | 8 |  4     | remote chat/completions | 7.75 | 0.515 | 0.643 | 0.717   |  100.0  |  0.0  | 2774.30 | 13.59 | 2787.88 | vllm_0.10.2 |  mm_test_dev1k_4server |
| multimodel-llm | 8 |  8     | remote chat/completions | 11.47 | 0.696  |  0.894 |  1.115  |  100.0  |  0.0  | 2774.30 | 13.74 | 2788.03 | vllm_0.10.2 |  mm_test_dev1k_4server |
| multimodel-llm | 8 |  16     | remote chat/completions | 15.00  | 1.060 | 1.415 | 2.023 |  100.0  |  0.0  | 2774.30 | 13.86 | 2788.15 | vllm_0.10.2 |  mm_test_dev1k_4server |
| multimodel-llm | 8 |  32     | remote chat/completions | 17.48 | 1.815 | 3.133 | 4.169  |  100.0  |  6.7 | 2774.30 | 13.68 | 2787.97 | vllm_0.10.2 |  mm_test_dev1k_4server |
