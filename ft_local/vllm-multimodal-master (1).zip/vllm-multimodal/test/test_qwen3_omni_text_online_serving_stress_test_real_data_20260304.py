"""压力测试脚本 - 用于测试 vLLM 多模态模型的在线服务性能

使用方法:
# 基本测试
python3 test_online_serving_stress_test.py --host 29.148.226.140 --port 8081 --model /models --concurrent 10 --requests 100

# 带超时限制的测试
python3 test_online_serving_stress_test.py --host 29.148.226.140 --port 8081 --model /models --concurrent 10 --requests 100 --max-response-time 2.0

# 并发度分析测试（仅文本）
python3 test_online_serving_stress_test.py --host 29.148.226.140 --port 8081 --model /models --test-type concurrent-analysis --requests 50 --concurrent-levels "1,5,10,20" --analysis-test-types "text" --max-response-time 3.0

# 并发度分析测试（仅多模态）
python3 test_online_serving_stress_test.py --host 29.148.226.140 --port 8081 --model /models --test-type concurrent-analysis --requests 30 --concurrent-levels "1,5,10,15" --analysis-test-types "multimodal" --max-response-time 3.0


python3 test_qwen3.py --host 29.163.225.134 --port 8081 --model /models --test-type concurrent-analysis  --concurrent-levels "16" --analysis-test-types "multimodal" --max-response-time 3.0 --data-file ./mm_test_dev1k_4server/dev12253-1229-0130-0210_1ktestdata_4server.json --requests 2000

python3 test_qwen3.py --host 29.163.243.169 --port 8081 --model /models --test-type concurrent-analysis  --concurrent-levels "16" --analysis-test-types "text" --max-response-time 3.0 --data-file ./mm_test_dev1k_4server/dev12253-1229-0130-0210_1ktestdata_4server.json --requests 2000
"""
import base64
import time
import statistics
import json
from typing import List, Dict, Any
from argparse import ArgumentParser
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor
import threading


@dataclass
class TestResult:
    """测试结果数据类"""
    success: bool
    response_time: float
    error_message: str = ""
    response_content: str = ""
    is_timeout: bool = False  # 是否超时
    prompt_tokens: int = 0  # 提示词token数
    completion_tokens: int = 0  # 完成token数
    total_tokens: int = 0  # 总token数


class PressureTester:
    """压力测试器"""
    
    def __init__(self, host: str, port: int, model: str, api_key: str = "EMPTY", max_response_time: float = None, 
                 system_content: str = "content", audio_path: str = "./mm_online_0105_4server/mm_online_0105_4server/0.wav",
                 test_data: List[Dict[str, Any]] = None):
        self.host = host
        self.port = port
        self.model = model
        self.api_key = api_key
        self.base_url = f"http://{host}:{port}/v1"
        self.results: List[TestResult] = []
        self.lock = threading.Lock()
        self.max_response_time = max_response_time  # 最大响应时间（秒）
        self.system_content = system_content  # system消息的content
        self.audio_path = audio_path  # 音频文件路径
        self.test_data = test_data  # 测试数据列表
        self.current_data_index = 0  # 当前使用的测试数据索引
        
    def encode_base64_content_from_file(self, local_file: str) -> str:
        """从文件编码base64内容"""
        try:
            with open(local_file, "rb") as audio_file:
                audio_base64 = base64.b64encode(audio_file.read()).decode("utf-8")
            return audio_base64
        except FileNotFoundError:
            # 如果文件不存在，创建一个最小有效的WAV文件
            # WAV文件头 + 少量音频数据（1秒，16kHz，16位PCM，单声道）
            import struct
            
            sample_rate = 16000
            duration = 1.0
            num_samples = int(sample_rate * duration)
            
            # 创建WAV文件头
            wav_header = bytearray()
            wav_header.extend(b'RIFF')
            # 文件大小 = 36 (header) + num_samples * 2 (16-bit samples)
            file_size = 36 + num_samples * 2
            wav_header.extend(struct.pack('<I', file_size))
            wav_header.extend(b'WAVE')
            wav_header.extend(b'fmt ')
            wav_header.extend(struct.pack('<I', 16))  # fmt chunk size
            wav_header.extend(struct.pack('<H', 1))   # audio format (PCM)
            wav_header.extend(struct.pack('<H', 1))   # num channels (mono)
            wav_header.extend(struct.pack('<I', sample_rate))  # sample rate
            wav_header.extend(struct.pack('<I', sample_rate * 2))  # byte rate
            wav_header.extend(struct.pack('<H', 2))   # block align
            wav_header.extend(struct.pack('<H', 16))  # bits per sample
            wav_header.extend(b'data')
            wav_header.extend(struct.pack('<I', num_samples * 2))  # data size
            
            # 生成静音音频数据（全零）
            audio_data = b'\x00\x00' * num_samples
            
            # 组合WAV文件
            wav_file = bytes(wav_header) + audio_data
            audio_base64 = base64.b64encode(wav_file).decode("utf-8")
            return audio_base64
    
    def create_text_request(self, data_item: Dict[str, Any] = None) -> Dict[str, Any]:
        """创建文本请求"""
        if data_item is None:
            return {
                "messages": [{
                    "role": "user",
                    "content": "What's the capital of France?"
                }],
                "model": self.model,
                "max_completion_tokens": 64,
            }
        else:
            system_content = data_item.get('system', self.system_content)
            text_content  = data_item.get('text_query', "")
            return {
                "prompt": system_content + "<｜User｜>" + text_content +"<｜Assistant｜><think>\n\n</think>\n\n",
                # "messages": [
                #     {
                #         "role": "system",
                #         "content": system_content
                #     },
                #     {
                #         "role": "user",
                #         "content": text_content+"<｜Assistant｜><think>\n\n</think>\n\n"
                #     }
                # ],
                "model": self.model,
                "max_completion_tokens": 64,
            }
            
    def create_audio_request(self) -> Dict[str, Any]:
        """创建音频请求"""
        audio_base64 = self.encode_base64_content_from_file("./result.wav")
        
        return {
            "messages": [{
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": "请将语音转移为文字。"
                    },
                    {
                        "type": "input_audio",
                        "input_audio": {
                            "data": audio_base64,
                            "format": "wav"
                        },
                    },
                ],
            }],
            "model": self.model,
            "max_completion_tokens": 64,
        }
    
    def create_multimodal_request(self, data_item: Dict[str, Any] = None) -> Dict[str, Any]:
        """创建多模态请求"""
        # 如果提供了data_item，使用其中的数据；否则使用默认值
        if data_item:
            system_content = data_item.get('system', self.system_content)
            audio_path = data_item.get('audios', [self.audio_path])[0] if data_item.get('audios') else self.audio_path
            # filename = audio_path.split("/")[-1]
            # print(f"filename:{filename}")
            # audio_path = f"./mm_online_0105_4server/mm_online_0105_4server/{filename}"
            filename = audio_path
            print(f"filename:{filename}")
            audio_path = f"./mm_test_dev1k_4server/{filename}"
        else:
            system_content = self.system_content
            audio_path = self.audio_path
        
        audio_base64 = self.encode_base64_content_from_file(audio_path)
        
        return {
            "modalities": ["text", "audio"],
            "messages": [
                {'role': 'system', 'content': system_content}, 
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": ""
                        },
                        {
                            "type": "input_audio",
                            "input_audio": {
                                "data": audio_base64,
                                "format": "wav"
                            },
                        },
                    ],
                }
            ],
            "model": self.model,
            "max_completion_tokens": 64,
        }
    
    def run_sync_test(self, request_type: str, num_requests: int, concurrent: int) -> List[TestResult]:
        """运行同步压力测试"""
        print(f"开始同步压力测试: {request_type}, 请求数: {num_requests}, 并发数: {concurrent}")
        
        results = []
        test_start_time = time.time()  # 记录测试开始时间
        
        # 准备请求数据列表
        request_data_list = []
        for i in range(num_requests):
            if request_type == "text":
                request_data_list.append(self.create_text_request(self.test_data[i]))
            elif request_type == "audio":
                request_data_list.append(self.create_audio_request())
            elif request_type == "multimodal":
                # 如果有测试数据，按顺序使用；否则使用默认配置
                if self.test_data and i < len(self.test_data):
                    request_data_list.append(self.create_multimodal_request(self.test_data[i]))
                else:
                    request_data_list.append(self.create_multimodal_request())
            else:
                raise ValueError(f"Unknown request type: {request_type}")
        
        def send_single_request(request_type, request_data):
            start_time = time.time()
            try:
                import requests
                if request_type == "text":
                    response = requests.post(
                        f"{self.base_url}/completions",
                        json=request_data,
                        headers={"Authorization": f"Bearer {self.api_key}"},
                        timeout=60
                    )
                else:
                    response = requests.post(
                        f"{self.base_url}/chat/completions",
                        json=request_data,
                        headers={"Authorization": f"Bearer {self.api_key}"},
                        timeout=60
                    )
                response_time = time.time() - start_time
                # 检查是否超时
                is_timeout = False
                print (f"Response: {response.text}")

                if self.max_response_time and response_time > self.max_response_time:
                    is_timeout = True
                
                if response.status_code == 200:
                    result_data = response.json()
                    if request_type == "text":
                        content = result_data.get("choices", [{}])[0].get("text", "")
                    else:
                        content = result_data.get("choices", [{}])[0].get("message", {}).get("content", "")
                    
                    # 提取token使用信息
                    usage = result_data.get("usage", {})
                    prompt_tokens = usage.get("prompt_tokens", 0)
                    completion_tokens = usage.get("completion_tokens", 0)
                    total_tokens = usage.get("total_tokens", 0)
                    
                    return TestResult(
                        success=True,
                        response_time=response_time,
                        response_content=content,
                        is_timeout=is_timeout,
                        prompt_tokens=prompt_tokens,
                        completion_tokens=completion_tokens,
                        total_tokens=total_tokens
                    )
                else:
                    # 尝试解析错误响应
                    error_detail = response.text
                    print(f"[DEBUG] 收到错误响应，状态码: {response.status_code}", flush=True)
                    print(f"[DEBUG] 响应头: {dict(response.headers)}", flush=True)
                    print(f"[DEBUG] 原始响应文本长度: {len(error_detail)}", flush=True)
                    
                    try:
                        error_json = response.json()
                        print(f"[DEBUG] 成功解析JSON错误响应: {error_json}", flush=True)
                        if "error" in error_json:
                            error_obj = error_json.get('error', {})
                            if isinstance(error_obj, dict):
                                # 尝试从多个字段获取错误信息
                                message = error_obj.get('message', '')
                                detail = error_obj.get('detail', '')
                                error_type = error_obj.get('type', '')
                                code = error_obj.get('code', '')
                                
                                # 如果message为空，尝试使用其他字段
                                if message:
                                    error_detail = message
                                elif detail:
                                    error_detail = detail
                                elif error_type:
                                    error_detail = f"{error_type} (code: {code})" if code else error_type
                                else:
                                    # 如果所有字段都为空，显示完整的error对象
                                    error_detail = f"完整错误对象: {error_obj}"
                                
                                # 如果仍然为空，使用原始JSON
                                if not error_detail or error_detail.strip() == '':
                                    error_detail = f"错误响应: {error_json}"
                            else:
                                error_detail = str(error_obj)
                    except Exception as parse_error:
                        # 如果无法解析JSON，使用原始文本
                        print(f"[DEBUG] 无法解析JSON，使用原始文本。解析错误: {parse_error}", flush=True)
                        print(f"[DEBUG] 原始响应文本前500字符: {error_detail[:500]}", flush=True)
                    
                    # 立即打印错误信息以便调试（使用flush确保立即输出）
                    error_msg_short = error_detail[:500] if len(error_detail) > 500 else error_detail
                    print(f"[ERROR] HTTP {response.status_code} - 错误详情: {error_msg_short}", flush=True)
                    
                    # 如果错误信息为空或很短，提示查看服务器日志
                    if not error_detail or len(error_detail.strip()) < 10:
                        print(f"[WARNING] 服务器返回 {response.status_code} 错误，但错误消息为空。", flush=True)
                        print(f"[WARNING] 请查看服务器端日志以获取详细错误信息。", flush=True)
                        print(f"[WARNING] 完整错误响应: {response.text}", flush=True)
                    
                    full_error_msg = f"HTTP {response.status_code}: {error_detail}"
                    if not error_detail or len(error_detail.strip()) < 10:
                        # 如果错误详情为空，保存完整的响应文本
                        full_error_msg = f"HTTP {response.status_code}: {response.text}"
                    
                    print(f"[DEBUG] 保存的错误信息: {full_error_msg[:200]}...", flush=True)
                    
                    return TestResult(
                        success=False,
                        response_time=response_time,
                        error_message=full_error_msg,
                        is_timeout=is_timeout
                    )
            except Exception as e:
                response_time = time.time() - start_time
                is_timeout = self.max_response_time and response_time > self.max_response_time
                return TestResult(
                    success=False,
                    response_time=response_time,
                    error_message=str(e),
                    is_timeout=is_timeout
                )
        
        # 使用线程池执行请求
        with ThreadPoolExecutor(max_workers=concurrent) as executor:
            futures = [executor.submit(send_single_request, request_type, request_data_list[i]) for i in range(num_requests)]
            
            for i, future in enumerate(futures):
                try:
                    result = future.result()
                    results.append(result)
                    # 如果请求失败，立即显示错误信息
                    if not result.success:
                        print(f"\n[请求 {i+1} 失败] 状态: success={result.success}, timeout={result.is_timeout}", flush=True)
                        print(f"[请求 {i+1} 失败] 错误信息: {result.error_message}", flush=True)
                    else:
                        print(f"[请求 {i+1} 成功] 响应时间: {result.response_time:.3f}秒", flush=True)
                    if (i + 1) % 10 == 0:
                        print(f"已完成 {i + 1}/{num_requests} 请求", flush=True)
                except Exception as e:
                    error_msg = str(e)
                    print(f"\n[请求 {i+1} 异常] {error_msg}", flush=True)
                    import traceback
                    print(f"[请求 {i+1} 异常堆栈] {traceback.format_exc()}", flush=True)
                    results.append(TestResult(
                        success=False,
                        response_time=0,
                        error_message=error_msg,
                        is_timeout=False
                    ))
        
        test_end_time = time.time()  # 记录测试结束时间
        total_test_time = test_end_time - test_start_time
        
        # 将总测试时间添加到结果中，用于QPS计算
        for result in results:
            result.total_test_time = total_test_time
        
        return results
    
    def print_statistics(self, results: List[TestResult], test_name: str):
        """打印统计信息"""
        successful_results = [r for r in results if r.success]
        failed_results = [r for r in results if not r.success]
        timeout_results = [r for r in results if r.is_timeout]
        
        print(f"\n{'='*60}")
        print(f"测试结果: {test_name}")
        print(f"{'='*60}")
        print(f"总请求数: {len(results)}")
        print(f"成功请求数: {len(successful_results)}")
        print(f"失败请求数: {len(failed_results)}")
        print(f"成功率: {len(successful_results)/len(results)*100:.2f}%")
        
        # 超时统计
        if self.max_response_time:
            print(f"超时请求数: {len(timeout_results)}")
            print(f"超时失败率: {len(timeout_results)/len(results)*100:.2f}%")
            print(f"最大响应时间限制: {self.max_response_time:.2f}秒")
        
        if successful_results:
            response_times = [r.response_time for r in successful_results]
            print(f"\n响应时间统计 (秒):")
            print(f"  平均响应时间: {statistics.mean(response_times):.3f}")
            print(f"  中位数响应时间: {statistics.median(response_times):.3f}")
            print(f"  最小响应时间: {min(response_times):.3f}")
            print(f"  最大响应时间: {max(response_times):.3f}")
            print(f"  95%分位数: {sorted(response_times)[int(len(response_times)*0.95)]:.3f}")
            print(f"  99%分位数: {sorted(response_times)[int(len(response_times)*0.99)]:.3f}")
            
            # 计算QPS - 使用实际测试时间
            if hasattr(successful_results[0], 'total_test_time'):
                total_test_time = successful_results[0].total_test_time
                qps = len(successful_results) / total_test_time
                print(f"  实际QPS: {qps:.2f} (基于总测试时间: {total_test_time:.2f}秒)")
            else:
                # 备用计算方法：使用响应时间范围
                total_time = max(response_times) - min(response_times) if len(response_times) > 1 else response_times[0]
                if total_time > 0:
                    qps = len(successful_results) / total_time
                    print(f"  估算QPS: {qps:.2f} (基于响应时间范围)")
            
            # Token统计
            prompt_tokens_list = [r.prompt_tokens for r in successful_results if r.prompt_tokens > 0]
            completion_tokens_list = [r.completion_tokens for r in successful_results if r.completion_tokens > 0]
            total_tokens_list = [r.total_tokens for r in successful_results if r.total_tokens > 0]
            
            if prompt_tokens_list:
                print(f"\nToken使用统计:")
                print(f"  平均Prompt Tokens: {statistics.mean(prompt_tokens_list):.2f}")
                print(f"  平均Completion Tokens: {statistics.mean(completion_tokens_list):.2f}")
                print(f"  平均Total Tokens: {statistics.mean(total_tokens_list):.2f}")
                print(f"  总Prompt Tokens: {sum(prompt_tokens_list)}")
                print(f"  总Completion Tokens: {sum(completion_tokens_list)}")
                print(f"  总Total Tokens: {sum(total_tokens_list)}")
        
        if failed_results:
            print(f"\n失败原因统计:")
            print(f"[DEBUG] 失败结果数量: {len(failed_results)}", flush=True)
            error_counts = {}
            error_details = {}  # 存储详细的错误信息
            for idx, result in enumerate(failed_results):
                print(f"[DEBUG] 处理失败结果 {idx+1}: success={result.success}, error_message长度={len(result.error_message) if result.error_message else 0}", flush=True)
                if result.is_timeout:
                    error_type = f"超时 (>{self.max_response_time:.2f}s)"
                else:
                    # 提取错误类型（HTTP状态码或异常类型）
                    error_msg = result.error_message or "未知错误"
                    print(f"[DEBUG] 错误消息: {error_msg[:100]}...", flush=True)
                    if error_msg.startswith("HTTP"):
                        error_type = error_msg.split(':')[0]  # "HTTP 500"
                    else:
                        error_type = error_msg.split(':')[0] if ':' in error_msg else error_msg[:50]
                
                error_counts[error_type] = error_counts.get(error_type, 0) + 1
                # 保存第一个错误的详细信息（保存完整信息，不截断）
                if error_type not in error_details:
                    error_details[error_type] = result.error_message
                    print(f"[DEBUG] 保存错误类型 '{error_type}' 的详细信息，长度: {len(result.error_message)}", flush=True)
            
            print(f"[DEBUG] 错误类型数量: {len(error_counts)}, 错误详情数量: {len(error_details)}", flush=True)
            for error, count in error_counts.items():
                print(f"  {error}: {count} 次", flush=True)
                if error in error_details:
                    detail = error_details[error]
                    print(f"[DEBUG] 准备显示错误类型 '{error}' 的详细信息，长度: {len(detail)}", flush=True)
                    # 显示完整错误信息，如果太长则截断但显示更多内容
                    if len(detail) > 500:
                        print(f"    详细错误信息: {detail[:500]}...", flush=True)
                        print(f"    (完整错误信息共 {len(detail)} 字符)", flush=True)
                    else:
                        print(f"    详细错误信息: {detail}", flush=True)
                else:
                    print(f"    [警告] 错误类型 '{error}' 没有详细信息", flush=True)
        
        # 超时详情统计
        if timeout_results:
            print(f"\n超时详情统计:")
            timeout_times = [r.response_time for r in timeout_results]
            print(f"  超时请求平均响应时间: {statistics.mean(timeout_times):.3f}秒")
            print(f"  最长超时时间: {max(timeout_times):.3f}秒")
            print(f"  最短超时时间: {min(timeout_times):.3f}秒")
    
    def run_comprehensive_test(self, num_requests: int, concurrent: int):
        """运行综合测试"""
        print(f"开始综合压力测试")
        print(f"服务器: {self.host}:{self.port}")
        print(f"模型: {self.model}")
        print(f"总请求数: {num_requests}")
        print(f"并发数: {concurrent}")
        
        # # 测试文本请求
        # print(f"\n{'='*40}")
        # print("测试1: 文本请求")
        # text_results = self.run_sync_test("text", num_requests, concurrent)
        # self.print_statistics(text_results, "文本请求")
        
        # # 测试音频请求
        # print(f"\n{'='*40}")
        # print("测试2: 音频请求")
        # audio_results = self.run_sync_test("audio", num_requests, concurrent)
        # self.print_statistics(audio_results, "音频请求")
        
        # 测试多模态请求
        print(f"\n{'='*40}")
        print("测试3: 多模态请求")
        multimodal_results = self.run_sync_test("multimodal", num_requests, concurrent)
        self.print_statistics(multimodal_results, "多模态请求")
        
        # 保存详细结果到文件
        self.save_results_to_file(multimodal_results)
    
    def run_concurrent_analysis(self, num_requests: int, concurrent_levels: list, test_types: list = None, output_file_base: str = "pressure_test_results"):
        """运行并发度分析测试"""
        if test_types is None:
            test_types = ["text"]
        
        print(f"开始并发度分析测试")
        print(f"服务器: {self.host}:{self.port}")
        print(f"模型: {self.model}")
        print(f"总请求数: {num_requests}")
        print(f"并发度测试: {concurrent_levels}")
        print(f"测试类型: {test_types}")
        
        analysis_results = {}
        
        for concurrent in concurrent_levels:
            print(f"\n{'='*50}")
            print(f"测试并发度: {concurrent}")
            print(f"{'='*50}")
            
            concurrent_results = {}
            
            for test_type in test_types:
                print(f"\n--- 测试类型: {test_type} ---")
                # 运行指定类型的测试
                test_results = self.run_sync_test(test_type, num_requests, concurrent)
                self.print_statistics(test_results, f"{test_type}请求 (并发度: {concurrent})")
                
                # 根据并发度和测试类型生成输出文件名
                output_file = f"{output_file_base}_{test_type}_{concurrent}.json"
                self.save_results_to_file(test_results, output_file)
                
                # 记录结果用于分析
                successful_results = [r for r in test_results if r.success]
                timeout_results = [r for r in test_results if r.is_timeout]
                
                if successful_results and hasattr(successful_results[0], 'total_test_time'):
                    total_time = successful_results[0].total_test_time
                    qps = len(successful_results) / total_time
                    avg_response_time = statistics.mean([r.response_time for r in successful_results])
                    
                    # 计算P95和P99
                    response_times = sorted([r.response_time for r in successful_results])
                    p95 = response_times[int(len(response_times) * 0.95)] if len(response_times) > 0 else 0
                    p99 = response_times[int(len(response_times) * 0.99)] if len(response_times) > 0 else 0
                    
                    # 计算token平均值
                    prompt_tokens_list = [r.prompt_tokens for r in successful_results if r.prompt_tokens > 0]
                    completion_tokens_list = [r.completion_tokens for r in successful_results if r.completion_tokens > 0]
                    total_tokens_list = [r.total_tokens for r in successful_results if r.total_tokens > 0]
                    
                    avg_prompt_tokens = statistics.mean(prompt_tokens_list) if prompt_tokens_list else 0
                    avg_completion_tokens = statistics.mean(completion_tokens_list) if completion_tokens_list else 0
                    avg_total_tokens = statistics.mean(total_tokens_list) if total_tokens_list else 0
                    
                    concurrent_results[test_type] = {
                        'qps': qps,
                        'avg_response_time': avg_response_time,
                        'p95': p95,
                        'p99': p99,
                        'success_rate': len(successful_results) / len(test_results) * 100,
                        'timeout_rate': len(timeout_results) / len(test_results) * 100,
                        'total_time': total_time,
                        'avg_prompt_tokens': avg_prompt_tokens,
                        'avg_completion_tokens': avg_completion_tokens,
                        'avg_total_tokens': avg_total_tokens
                    }
            
            analysis_results[concurrent] = concurrent_results
        
        # 打印并发度分析总结
        for test_type in test_types:
            print(f"\n{'='*120}")
            print(f"并发度分析总结 - {test_type}请求")
            print(f"{'='*120}")
            
            # 检查是否有token数据
            has_token_data = False
            for concurrent in sorted(analysis_results.keys()):
                if test_type in analysis_results[concurrent]:
                    result = analysis_results[concurrent][test_type]
                    if result.get('avg_prompt_tokens', 0) > 0:
                        has_token_data = True
                        break
            
            if self.max_response_time:
                if has_token_data:
                    # 包含Token统计的表格
                    print(f"{'并发度':<8} {'QPS':<10} {'平均响应(秒)':<14} {'P95(秒)':<10} {'P99(秒)':<10} {'成功率(%)':<12} {'超时率(%)':<12} {'平均Prompt':<14} {'平均Completion':<16} {'平均Total':<12}")
                    print("-" * 138)
                    
                    for concurrent in sorted(analysis_results.keys()):
                        if test_type in analysis_results[concurrent]:
                            result = analysis_results[concurrent][test_type]
                            print(f"{concurrent:<8} {result['qps']:<10.2f} {result['avg_response_time']:<14.3f} "
                                  f"{result.get('p95', 0):<10.3f} {result.get('p99', 0):<10.3f} "
                                  f"{result['success_rate']:<12.1f} {result['timeout_rate']:<12.1f} "
                                  f"{result.get('avg_prompt_tokens', 0):<14.2f} {result.get('avg_completion_tokens', 0):<16.2f} {result.get('avg_total_tokens', 0):<12.2f}")
                else:
                    # 不包含Token统计的表格
                    print(f"{'并发度':<8} {'QPS':<10} {'平均响应(秒)':<14} {'P95(秒)':<10} {'P99(秒)':<10} {'成功率(%)':<12} {'超时率(%)':<12}")
                    print("-" * 86)
                    
                    for concurrent in sorted(analysis_results.keys()):
                        if test_type in analysis_results[concurrent]:
                            result = analysis_results[concurrent][test_type]
                            print(f"{concurrent:<8} {result['qps']:<10.2f} {result['avg_response_time']:<14.3f} "
                                  f"{result.get('p95', 0):<10.3f} {result.get('p99', 0):<10.3f} "
                                  f"{result['success_rate']:<12.1f} {result['timeout_rate']:<12.1f}")
            else:
                if has_token_data:
                    # 包含Token统计的表格（无超时率）
                    print(f"{'并发度':<8} {'QPS':<10} {'平均响应(秒)':<14} {'P95(秒)':<10} {'P99(秒)':<10} {'成功率(%)':<12} {'平均Prompt':<14} {'平均Completion':<16} {'平均Total':<12}")
                    print("-" * 126)
                    
                    for concurrent in sorted(analysis_results.keys()):
                        if test_type in analysis_results[concurrent]:
                            result = analysis_results[concurrent][test_type]
                            print(f"{concurrent:<8} {result['qps']:<10.2f} {result['avg_response_time']:<14.3f} "
                                  f"{result.get('p95', 0):<10.3f} {result.get('p99', 0):<10.3f} "
                                  f"{result['success_rate']:<12.1f} "
                                  f"{result.get('avg_prompt_tokens', 0):<14.2f} {result.get('avg_completion_tokens', 0):<16.2f} {result.get('avg_total_tokens', 0):<12.2f}")
                else:
                    # 不包含Token统计的表格（无超时率）
                    print(f"{'并发度':<8} {'QPS':<10} {'平均响应(秒)':<14} {'P95(秒)':<10} {'P99(秒)':<10} {'成功率(%)':<12}")
                    print("-" * 74)
                    
                    for concurrent in sorted(analysis_results.keys()):
                        if test_type in analysis_results[concurrent]:
                            result = analysis_results[concurrent][test_type]
                            print(f"{concurrent:<8} {result['qps']:<10.2f} {result['avg_response_time']:<14.3f} "
                                  f"{result.get('p95', 0):<10.3f} {result.get('p99', 0):<10.3f} "
                                  f"{result['success_rate']:<12.1f}")
            
            # 分析性能趋势
            print(f"\n{test_type}请求性能分析:")
            qps_values = []
            for concurrent in sorted(analysis_results.keys()):
                if test_type in analysis_results[concurrent]:
                    qps_values.append(analysis_results[concurrent][test_type]['qps'])
            
            if len(qps_values) > 1:
                if qps_values[-1] > qps_values[0]:
                    print(f"  - QPS随并发度增加而提升，系统可能还有余量")
                elif qps_values[-1] < qps_values[0] * 0.8:
                    print(f"  - QPS随并发度增加而下降，可能存在性能瓶颈")
                else:
                    print(f"  - QPS相对稳定，系统性能较为均衡")
        
        # 综合性能对比
        if len(test_types) > 1:
            print(f"\n{'='*80}")
            print("多类型性能对比")
            print(f"{'='*80}")
            print(f"{'测试类型':<12} {'最佳并发度':<12} {'最高QPS':<10} {'平均响应时间(秒)':<15}")
            print("-" * 80)
            
            for test_type in test_types:
                best_concurrent = None
                best_qps = 0
                best_avg_time = 0
                
                for concurrent in sorted(analysis_results.keys()):
                    if test_type in analysis_results[concurrent]:
                        result = analysis_results[concurrent][test_type]
                        if result['qps'] > best_qps:
                            best_qps = result['qps']
                            best_concurrent = concurrent
                            best_avg_time = result['avg_response_time']
                
                if best_concurrent is not None:
                    print(f"{test_type:<12} {best_concurrent:<12} {best_qps:<10.2f} {best_avg_time:<15.3f}")
        
        return analysis_results
    
    def save_results_to_file(self, results, filename: str = "pressure_test_results.json"):
        """保存结果到文件"""
        results_data = {
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "host": self.host,
            "port": self.port,
            "model": self.model,
            "results": [
                {
                    "success": r.success,
                    "response_time": r.response_time,
                    "error_message": r.error_message,
                    "response_content": r.response_content[:100] + "..." if len(r.response_content) > 100 else r.response_content,
                    "is_timeout": r.is_timeout,
                    "prompt_tokens": r.prompt_tokens,
                    "completion_tokens": r.completion_tokens,
                    "total_tokens": r.total_tokens
                } for r in results
            ]
        }
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(results_data, f, ensure_ascii=False, indent=2)
        
        print(f"\n详细结果已保存到: {filename}")


def main():
    parser = ArgumentParser(
        description='vLLM 多模态模型压力测试工具'
    )
    parser.add_argument("--host", type=str, default="localhost", help="FastAPI server host")
    parser.add_argument("--port", type=int, default=8081, help="FastAPI server port")
    parser.add_argument("--model", type=str, default="/models", help="Model name")
    parser.add_argument("--requests", type=int, default=100, help="总请求数")
    parser.add_argument("--concurrent", type=int, default=10, help="并发数")
    parser.add_argument("--test-type", type=str, default="all", 
                       choices=["text", "audio", "multimodal", "all", "concurrent-analysis"],
                       help="测试类型")
    parser.add_argument("--concurrent-levels", type=str, default="1,5,10,20,30", 
                       help="并发度分析测试的并发级别，用逗号分隔")
    parser.add_argument("--analysis-test-types", type=str, default="text", 
                       help="并发度分析测试的测试类型，用逗号分隔，可选: text,audio,multimodal")
    parser.add_argument("--max-response-time", type=float, default=None,
                       help="最大响应时间（秒），超过此时间的请求将被统计为超时失败")
    parser.add_argument("--system-content", type=str, default="content",
                       help="system消息的content内容（当不使用--data-file时生效）")
    parser.add_argument("--audio-path", type=str, default="./mm_online_0105_4server/mm_online_0105_4server/0.wav",
                       help="音频文件路径（当不使用--data-file时生效）")
    parser.add_argument("--data-file", type=str, default=None,
                       help="测试数据JSON文件路径，包含system和audios字段")
    parser.add_argument("--output-file", type=str, default="pressure_test_results.json",
                       help="输出文件路径（并发度分析时会自动添加并发度后缀）")
    
    args = parser.parse_args()
    
    # 加载测试数据
    test_data = None
    if args.data_file:
        try:
            with open(args.data_file, 'r', encoding='utf-8') as f:
                test_data = json.load(f)
            print(f"成功加载测试数据文件: {args.data_file}")
            print(f"数据文件包含 {len(test_data)} 条记录")
            
            # 根据请求数截取数据
            if args.requests < len(test_data):
                test_data = test_data[:args.requests]
                print(f"根据--requests参数，使用前 {args.requests} 条数据")
            elif args.requests > len(test_data):
                print(f"警告: 请求数({args.requests})大于数据文件记录数({len(test_data)})，将使用所有数据")
                args.requests = len(test_data)
        except FileNotFoundError:
            print(f"错误: 找不到数据文件 {args.data_file}")
            return
        except json.JSONDecodeError as e:
            print(f"错误: 无法解析JSON文件 {args.data_file}: {e}")
            return
    
    # 创建压力测试器
    tester = PressureTester(args.host, args.port, args.model, max_response_time=args.max_response_time,
                           system_content=args.system_content, audio_path=args.audio_path,
                           test_data=test_data)
    
    if args.test_type == "all":
        # 运行综合测试
        tester.run_comprehensive_test(args.requests, args.concurrent)
    elif args.test_type == "concurrent-analysis":
        # 运行并发度分析测试
        concurrent_levels = [int(x.strip()) for x in args.concurrent_levels.split(',')]
        test_types = [x.strip() for x in args.analysis_test_types.split(',')]
        
        # 从output_file中提取基础文件名（去掉.json后缀）
        output_file_base = args.output_file.replace('.json', '') if args.output_file.endswith('.json') else args.output_file
        
        tester.run_concurrent_analysis(args.requests, concurrent_levels, test_types, output_file_base)
    else:
        # 运行单一类型测试
        print(f"开始 {args.test_type} 压力测试")
        results = tester.run_sync_test(args.test_type, args.requests, args.concurrent)
        tester.print_statistics(results, f"{args.test_type} 请求")
        tester.save_results_to_file(results, args.output_file)


if __name__ == "__main__":
    main()
