from io import BytesIO
from urllib.request import urlopen
import librosa, torch, torchaudio
# from transformers import AutoProcessor, AutoModel
from llamafactory.model.speech_encoder.build_model import build_fireasr
from llamafactory.model.speech_encoder.custom_processor import FireASRAudioProcessor
from llamafactory.model.speech_encoder.modeling_custom_qwen2_audio import CustomQwen2AudioForConditionalGeneration
build_fireasr()
import time, os
from glob import glob
from safetensors.torch import load_file, save_file

from torch.cuda.amp import autocast

ckpt = '/models'
precision = torch.bfloat16
# ckpt = '/apdcephfs/share_303556863/jingyulli/pretrain/fireasr_deepseek_audio'
processor = FireASRAudioProcessor.from_pretrained(
    ckpt,
    torch_dtype=precision
)
model = CustomQwen2AudioForConditionalGeneration.from_pretrained(
    ckpt, 
    device_map="auto",
    torch_dtype=precision
)

conversation = [
    # {'role': 'system', 'content': 'You are a helpful assistant.'}, 
    {"role": "<｜User｜>", "content": [
        {"type": "text", "text": "请将语音转移为文字。<audio>"},
        {"type": "audio", "audio": "./result.wav"},
    ]},
]

text = processor.apply_chat_template(conversation, add_generation_prompt=True, tokenize=False)
print(text)
text = text.replace('<audio>', '')
text = text.replace('<｜User｜>', '')
text = text.replace('<|audio_bos|>', "<｜User｜>")
text = text.replace('<|audio_eos|>', '')


print('=' * 10)
print(text)
audios = []
for message in conversation:
    if isinstance(message["content"], list):
        for ele in message["content"]:
            if ele["type"] == "audio":
                audio, sr = torchaudio.load(ele["audio"])
                audio = audio[0].numpy()
                print('audio size', audio.shape, sr)
                audios.append(audio)

inputs = processor(text=text, audios=audios, return_tensors="pt", padding=True, sampling_rate=16000)


for k in inputs:
    inputs[k] = inputs[k].to("cuda")

with autocast():
    generate_ids = model.generate(**inputs, max_new_tokens=100)
    # generate_ids = generate_ids[:, inputs.input_ids.size(1):]

    response = processor.batch_decode(generate_ids, skip_special_tokens=False, clean_up_tokenization_spaces=False)
    print(response)
