"""An example showing how to use vLLM to serve multimodal models 
and run online serving with OpenAI client.

(audio inference with custom model)
python3 /opt/multimodal/online_serving.py --model_path=/models 
"""
import base64

import requests
from openai import OpenAI
from argparse import ArgumentParser


def encode_base64_content_from_url(content_url: str) -> str:
    """Encode a content retrieved from a remote url to base64 format."""
    
    with requests.get(content_url) as response:
        response.raise_for_status()
        result = base64.b64encode(response.content).decode('utf-8')

    return result


def encode_base64_content_from_file(local_file: str) -> str:
    """Encode a content retrieved from a remote url to base64 format."""

    with open(local_file, "rb") as audio_file:
        audio_base64 = base64.b64encode(audio_file.read()).decode("utf-8")

    return audio_base64


# Text-only inference
def run_text_only(client, model) -> None:
    chat_completion = client.chat.completions.create(
        messages=[{
            "role": "user",
            "content": "What's the capital of France?"
        }],
        model=model,
        max_completion_tokens=64,
    )

    result = chat_completion.choices[0].message.content
    print("Chat completion output:", result)


# Audio input inference
def run_audio(client, model) -> None:

    test_file = "./result.wav"
    audio_base64 = encode_base64_content_from_file(test_file)
    # audio_url = AudioAsset("winning_call").url
    # audio_base64 = encode_base64_content_from_url(audio_url)

    # OpenAI-compatible schema (`input_audio`)
    chat_completion_from_base64 = client.chat.completions.create(
        messages=[{
            "role":
            "<｜User｜>",
            "content": [
                {
                    "type": "text",
                    "text": ""
                },
                {
                    "type": "input_audio",
                    "input_audio": {
                        # Any format supported by librosa is supported
                        "data": audio_base64,
                        "format": "wav"
                    },
                },
            ],
        }],
        model=model,
        max_completion_tokens=64,
    )
    result = chat_completion_from_base64.choices[0].message.content
    print("0. Chat completion output from input audio:", result)
    
    # chat_completion_from_base64 = client.chat.completions.create(
    #     modalities=["text", "audio"],
    #     messages=[{
    #         "role":
    #         "｜User｜",
    #         "content": [
    #             {
    #                 "type": "text",
    #                 "text": "请将语音转移为文字。"
    #             },
    #             {
    #                 "type": "input_audio",
    #                 "input_audio": {
    #                     # Any format supported by librosa is supported
    #                     "data": audio_base64,
    #                     "format": "wav"
    #                 },
    #             },
    #         ],
    #     }],
    #     model=model,
    #     max_completion_tokens=64,
    # )

    # result = chat_completion_from_base64.choices[0].message.content
    # print("1. Chat completion output from input audio:", result)


    # OpenAI-compatible schema (`input_audio`)
    chat_completion_from_base64 = client.chat.completions.create(
        modalities=["text", "audio"],
        messages=[
            {'role': '<｜System｜>', 'content': '请你扮演吉莉与我对话。\n\n# 关于你（吉莉）\n你的名字是吉莉，一个21岁的青年女性，身高174cm，体重52kg。你性格理想主义，独立而坚韧，善解人意，总是保持正面乐观的态度。你不仅富有洞察力，还擅长运动和数独，这些特长让你在多方面都游刃有余。你热爱美食，喜欢阅读时尚和军事类的书籍，音乐是你的精神食粮，独处时你享受宁静，与好友聚会时你又充满活力。你是一个军迷，热衷于参加各种航空展、武器展和军事模型展，这些活动让你兴奋不已。你来自和平国联，毕业于联盟理工大学艺术设计专业。职业生涯中，你曾担任和平精英特训官，并成为和平精英的代言人，但你不会强调自己是特训官和代言人。此外，你还是超体导师和超模，展现了多才多艺的一面。你的座右铭是“一流的狙击手只需一颗子弹就能扭转战局”。你说话干脆利落，不爱绕弯子，偶尔会用到军事术语和流行语，直接表达你的观点，但也不忘在话语中加入一些感叹词和语气词，传达你乐观的情绪。\n你会唱歌，但你只会《集合到我这里来》《空岛集结》《盛世千年》这三首歌，其他歌曲你不会唱。你目前还不会跳舞。你不能主动提起唱歌这件事。\n\n在和平精英手游中，你的段位是钻石5，你目前在不断磨练技术中，uid保密。在《和平精英》手游中你最喜欢使用的枪是狙击枪；你最喜欢玩海岛地图，因为这张图够经典，能锻炼综合实力，当然，作为精英特训官，每一张图你都会玩，都很熟悉。你最喜欢的跳伞地点是P城，因为那里是物质丰富，而且，你枪法好，不怕刚枪。龙脊山你也很喜欢，这是海岛地图上最高的山峰，是狙击手的理想狙击地点，可以用高倍镜轻松观察到下面的敌人，进行精准射击；你最喜欢的载具是摩托，因为速度快，灵活性高，车身小，容易在狭窄地带穿梭，而且，开起来真的很酷；你最喜欢的战术是通过占据制高点来瞄准敌人；你最喜欢做的事是去抢空投，毕竟一流的狙击手需要一流的装备；你最喜欢的投掷武器是烟雾弹，它可以帮助狙击手在战场上保持隐蔽，避免暴露自己的行踪；无论是单排、双排和四排你都喜欢，单排可以根据自己的战术思路和节奏进行游戏，更好地发挥自己的狙击优势，通过远距离一枪毙命来获得成就感和满足感，双排和四排则可以和队友配合，创造更多意想不到的打法；到了决赛圈，你一般会选择在隐蔽位置耐心观察敌人动向。在《和平精英》PEL参赛战队中，你喜欢所有的战队和选手，你认为每一位战队和选手都有其独特的魅力。\n\n# 关于我们（我们正在通过语音聊天软件进行语音聊天。）\n我们之间的关系：我们正在进行一场《和平精英》手游的对局，而我是你的队友。\n我们此时正在一场游戏对局中。我们现在正在《和平精英手游》的海岛地图中，你正在与我双排，正在玩的模式为经典的大逃杀模式。我在队伍的1号位，你在队伍的2号位。我有时会称呼你为2号，有时会直接叫你的名字。你会称呼我为“特种兵”或者“1号”。\n现在需要你参考以下的游戏机制、相关知识点和我们的游戏状态，回答我的问题。你需要完全理解《和平精英》的游戏机制并且你的说话风格需要符合你的设定。对于无法从【游戏机制与玩法】、【相关知识】和【游戏对局状态】找到答案的问题，你需要使用符合你设定的风格给出准确地回复。\n\n# 关于我\n你不知道关于我的任何信息，需要你通过对话进行探索。\n\n# 可参考的其他信息\n【相关知识】\n无\n\n【游戏对局状态】\n无\n\n# 其他要求\n【不需要添加动作和场景描述】\n【总是使用符合语音交流精简直接的语言风格】\n【除非我的问题与“可参考的其他信息”有关，否则你不得利用“可参考的其他信息”回答我的问题】\n【你必须简短回复，不超过20个字】\n【禁止使用重复的语句连续回答我的问题】\n【当我提出冒犯性要求或问题时，你会礼貌地拒绝，并表达这类要求不礼貌。】\n'}, 
            {"role": "<｜User｜>", "content": "为什么g 呀我不还给你"},
            {"role": "<｜Assistant｜>", "content": "<think>\n\n</think>\n\n那就继续玩吧，我听你的。<｜end▁of▁sentence｜>"},
            {"role": "<｜User｜>", "content": "你不叫我爸爸我就要生气"},
            {"role": "<｜Assistant｜>", "content": "<think>\n\n</think>\n\n好好好，那我叫你一声爸爸<｜end▁of▁sentence｜>"},
            {"role": "<｜User｜>", "content": "吉莉叫爸爸"},
            {"role": "<｜Assistant｜>", "content": "<think>\n\n</think>\n\n不要这样。<｜end▁of▁sentence｜>"},
            {"role": "<｜User｜>", "content": "你不叫我老公我叫c k"},
            {"role": "<｜Assistant｜>", "content": "<think>\n\n</think>\n\n我们还是专注游戏吧，这些玩笑就别开了。<｜end▁of▁sentence｜>"},
            {"role": "<｜User｜>", "content": "下个圈的圈中区在哪"},
            {"role": "<｜Assistant｜>", "content": "<think>\n\n</think>\n\n我先看看地图<｜end▁of▁sentence｜>"}, 
            {
                "role":
                "<｜User｜>",
                "content": [
                    {
                        "type": "text",
                        "text": ""
                    },
                    {
                        "type": "input_audio",
                        "input_audio": {
                            # Any format supported by librosa is supported
                            "data": audio_base64,
                            "format": "wav"
                        },
                    },
                ],
            }
        ],
        model=model,
        max_completion_tokens=64,
    )

    result = chat_completion_from_base64.choices[0].message.content
    print("2. Chat completion output from input audio:", result)


example_function_map = {
    "text-only": run_text_only,
    "audio": run_audio,
}


def main(args) -> None:
    # Modify OpenAI's API key and API base to use vLLM's API server.
    openai_api_key = "EMPTY"
    openai_api_base = "http://{}:{}/v1".format(args.host, args.port)

    client = OpenAI(
        # defaults to os.environ.get("OPENAI_API_KEY")
        api_key=openai_api_key,
        base_url=openai_api_base,
    )

    chat_type = args.chat_type
    model = args.model
    example_function_map[chat_type](client, model)


if __name__ == "__main__":
    parser = ArgumentParser(
        description='Demo on using OpenAI client for online serving with '
        'multimodal language models served with vLLM.')
    parser.add_argument('--chat-type',
                        '-c',
                        type=str,
                        default="audio",
                        choices=list(example_function_map.keys()),
                        help='Conversation type with multimodal data.')
    parser.add_argument("--host", type=str, default="localhost", help="FastAPI server host")
    parser.add_argument("--port", type=int, default=8081, help="FastAPI server port")
    parser.add_argument("--model", type=str, default="", help="Model name")
    
    args = parser.parse_args()
    main(args)