"""压力测试脚本 - 用于测试 vLLM 多模态模型的在线服务性能

使用方法:
# 基本测试
python3 test_online_serving_stress_test.py --host 29.148.226.140 --port 8081 --model /models --concurrent 10 --requests 100

# 带超时限制的测试
python3 test_online_serving_stress_test.py --host 29.148.226.140 --port 8081 --model /models --concurrent 10 --requests 100 --max-response-time 2.0

# 并发度分析测试（仅文本）
python3 test_online_serving_stress_test.py --host 29.148.226.140 --port 8081 --model /models --test-type concurrent-analysis --requests 50 --concurrent-levels "1,5,10,20" --analysis-test-types "text" --max-response-time 3.0

# 并发度分析测试（仅多模态）
python3 test_online_serving_stress_test.py --host 29.148.226.140 --port 8081 --model /models --test-type concurrent-analysis --requests 30 --concurrent-levels "1,5,10,15" --analysis-test-types "multimodal" --max-response-time 3.0
"""
import base64
import time
import statistics
import json
from typing import List, Dict, Any
from argparse import ArgumentParser
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor
import threading


@dataclass
class TestResult:
    """测试结果数据类"""
    success: bool
    response_time: float
    error_message: str = ""
    response_content: str = ""
    is_timeout: bool = False  # 是否超时


class PressureTester:
    """压力测试器"""
    
    def __init__(self, host: str, port: int, model: str, api_key: str = "EMPTY", max_response_time: float = None):
        self.host = host
        self.port = port
        self.model = model
        self.api_key = api_key
        self.base_url = f"http://{host}:{port}/v1"
        self.results: List[TestResult] = []
        self.lock = threading.Lock()
        self.max_response_time = max_response_time  # 最大响应时间（秒）
        
    def encode_base64_content_from_file(self, local_file: str) -> str:
        """从文件编码base64内容"""
        try:
            with open(local_file, "rb") as audio_file:
                audio_base64 = base64.b64encode(audio_file.read()).decode("utf-8")
            return audio_base64
        except FileNotFoundError:
            # 如果文件不存在，创建一个模拟的base64数据
            dummy_audio = b"dummy_audio_data_for_testing" * 100  # 模拟音频数据
            return base64.b64encode(dummy_audio).decode("utf-8")
    
    def create_text_request(self) -> Dict[str, Any]:
        """创建文本请求"""
        return {
            "messages": [{
                "role": "user",
                "content": "What's the capital of France?"
            }],
            "model": self.model,
            "max_completion_tokens": 64,
        }
    
    def create_audio_request(self) -> Dict[str, Any]:
        """创建音频请求"""
        audio_base64 = self.encode_base64_content_from_file("./result.wav")
        
        return {
            "messages": [{
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": "请将语音转移为文字。"
                    },
                    {
                        "type": "input_audio",
                        "input_audio": {
                            "data": audio_base64,
                            "format": "wav"
                        },
                    },
                ],
            }],
            "model": self.model,
            "max_completion_tokens": 64,
        }
    
    def create_multimodal_request(self) -> Dict[str, Any]:
        """创建多模态请求"""
        audio_base64 = self.encode_base64_content_from_file("./result.wav")
        
        return {
            "modalities": ["text", "audio"],
            "messages": [
                {'role': 'system', 'content': '你是一个AI助手，请简短回答问题，不可以偷懒，不可以说自己只是语言模型，没有处理音频的能力，态度要积极'}, 
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": "请分析这段音频内容。"
                        },
                        {
                            "type": "input_audio",
                            "input_audio": {
                                "data": audio_base64,
                                "format": "wav"
                            },
                        },
                    ],
                }
            ],
            "model": self.model,
            "max_completion_tokens": 64,
        }
    
    def run_sync_test(self, request_type: str, num_requests: int, concurrent: int) -> List[TestResult]:
        """运行同步压力测试"""
        print(f"开始同步压力测试: {request_type}, 请求数: {num_requests}, 并发数: {concurrent}")
        
        # 创建请求数据
        if request_type == "text":
            request_data = self.create_text_request()
        elif request_type == "audio":
            request_data = self.create_audio_request()
        elif request_type == "multimodal":
            request_data = self.create_multimodal_request()
        else:
            raise ValueError(f"Unknown request type: {request_type}")
        
        results = []
        test_start_time = time.time()  # 记录测试开始时间
        
        def send_single_request():
            start_time = time.time()
            try:
                import requests
                response = requests.post(
                    f"{self.base_url}/chat/completions",
                    json=request_data,
                    headers={"Authorization": f"Bearer {self.api_key}"},
                    timeout=60
                )
                response_time = time.time() - start_time
                
                # 检查是否超时
                is_timeout = False
                if self.max_response_time and response_time > self.max_response_time:
                    is_timeout = True
                
                if response.status_code == 200:
                    result_data = response.json()
                    content = result_data.get("choices", [{}])[0].get("message", {}).get("content", "")
                    print (f"Result content: {content}")
                    return TestResult(
                        success=True,
                        response_time=response_time,
                        response_content=content,
                        is_timeout=is_timeout
                    )
                else:
                    return TestResult(
                        success=False,
                        response_time=response_time,
                        error_message=f"HTTP {response.status_code}: {response.text}",
                        is_timeout=is_timeout
                    )
            except Exception as e:
                response_time = time.time() - start_time
                is_timeout = self.max_response_time and response_time > self.max_response_time
                return TestResult(
                    success=False,
                    response_time=response_time,
                    error_message=str(e),
                    is_timeout=is_timeout
                )
        
        # 使用线程池执行请求
        with ThreadPoolExecutor(max_workers=concurrent) as executor:
            futures = [executor.submit(send_single_request) for _ in range(num_requests)]
            
            for i, future in enumerate(futures):
                try:
                    result = future.result()
                    results.append(result)
                    if (i + 1) % 10 == 0:
                        print(f"已完成 {i + 1}/{num_requests} 请求")
                except Exception as e:
                    results.append(TestResult(
                        success=False,
                        response_time=0,
                        error_message=str(e),
                        is_timeout=False
                    ))
        
        test_end_time = time.time()  # 记录测试结束时间
        total_test_time = test_end_time - test_start_time
        
        # 将总测试时间添加到结果中，用于QPS计算
        for result in results:
            result.total_test_time = total_test_time
        
        return results
    
    def print_statistics(self, results: List[TestResult], test_name: str):
        """打印统计信息"""
        successful_results = [r for r in results if r.success]
        failed_results = [r for r in results if not r.success]
        timeout_results = [r for r in results if r.is_timeout]
        
        print(f"\n{'='*60}")
        print(f"测试结果: {test_name}")
        print(f"{'='*60}")
        print(f"总请求数: {len(results)}")
        print(f"成功请求数: {len(successful_results)}")
        print(f"失败请求数: {len(failed_results)}")
        print(f"成功率: {len(successful_results)/len(results)*100:.2f}%")
        
        # 超时统计
        if self.max_response_time:
            print(f"超时请求数: {len(timeout_results)}")
            print(f"超时失败率: {len(timeout_results)/len(results)*100:.2f}%")
            print(f"最大响应时间限制: {self.max_response_time:.2f}秒")
        
        if successful_results:
            response_times = [r.response_time for r in successful_results]
            print(f"\n响应时间统计 (秒):")
            print(f"  平均响应时间: {statistics.mean(response_times):.3f}")
            print(f"  中位数响应时间: {statistics.median(response_times):.3f}")
            print(f"  最小响应时间: {min(response_times):.3f}")
            print(f"  最大响应时间: {max(response_times):.3f}")
            print(f"  95%分位数: {sorted(response_times)[int(len(response_times)*0.95)]:.3f}")
            print(f"  99%分位数: {sorted(response_times)[int(len(response_times)*0.99)]:.3f}")
            
            # 计算QPS - 使用实际测试时间
            if hasattr(successful_results[0], 'total_test_time'):
                total_test_time = successful_results[0].total_test_time
                qps = len(successful_results) / total_test_time
                print(f"  实际QPS: {qps:.2f} (基于总测试时间: {total_test_time:.2f}秒)")
            else:
                # 备用计算方法：使用响应时间范围
                total_time = max(response_times) - min(response_times) if len(response_times) > 1 else response_times[0]
                if total_time > 0:
                    qps = len(successful_results) / total_time
                    print(f"  估算QPS: {qps:.2f} (基于响应时间范围)")
        
        if failed_results:
            print(f"\n失败原因统计:")
            error_counts = {}
            for result in failed_results:
                if result.is_timeout:
                    error_type = f"超时 (>{self.max_response_time:.2f}s)"
                else:
                    error_type = result.error_message.split(':')[0] if ':' in result.error_message else result.error_message
                error_counts[error_type] = error_counts.get(error_type, 0) + 1
            
            for error, count in error_counts.items():
                print(f"  {error}: {count} 次")
        
        # 超时详情统计
        if timeout_results:
            print(f"\n超时详情统计:")
            timeout_times = [r.response_time for r in timeout_results]
            print(f"  超时请求平均响应时间: {statistics.mean(timeout_times):.3f}秒")
            print(f"  最长超时时间: {max(timeout_times):.3f}秒")
            print(f"  最短超时时间: {min(timeout_times):.3f}秒")
    
    def run_comprehensive_test(self, num_requests: int, concurrent: int):
        """运行综合测试"""
        print(f"开始综合压力测试")
        print(f"服务器: {self.host}:{self.port}")
        print(f"模型: {self.model}")
        print(f"总请求数: {num_requests}")
        print(f"并发数: {concurrent}")
        
        # 测试文本请求
        print(f"\n{'='*40}")
        print("测试1: 文本请求")
        text_results = self.run_sync_test("text", num_requests, concurrent)
        self.print_statistics(text_results, "文本请求")
        
        # 测试音频请求
        print(f"\n{'='*40}")
        print("测试2: 音频请求")
        audio_results = self.run_sync_test("audio", num_requests, concurrent)
        self.print_statistics(audio_results, "音频请求")
        
        # 测试多模态请求
        print(f"\n{'='*40}")
        print("测试3: 多模态请求")
        multimodal_results = self.run_sync_test("multimodal", num_requests, concurrent)
        self.print_statistics(multimodal_results, "多模态请求")
        
        # 保存详细结果到文件
        self.save_results_to_file(text_results, audio_results, multimodal_results)
    
    def run_concurrent_analysis(self, num_requests: int, concurrent_levels: list, test_types: list = None):
        """运行并发度分析测试"""
        if test_types is None:
            test_types = ["text"]
        
        print(f"开始并发度分析测试")
        print(f"服务器: {self.host}:{self.port}")
        print(f"模型: {self.model}")
        print(f"总请求数: {num_requests}")
        print(f"并发度测试: {concurrent_levels}")
        print(f"测试类型: {test_types}")
        
        analysis_results = {}
        
        for concurrent in concurrent_levels:
            print(f"\n{'='*50}")
            print(f"测试并发度: {concurrent}")
            print(f"{'='*50}")
            
            concurrent_results = {}
            
            for test_type in test_types:
                print(f"\n--- 测试类型: {test_type} ---")
                # 运行指定类型的测试
                test_results = self.run_sync_test(test_type, num_requests, concurrent)
                self.print_statistics(test_results, f"{test_type}请求 (并发度: {concurrent})")
                
                # 记录结果用于分析
                successful_results = [r for r in test_results if r.success]
                timeout_results = [r for r in test_results if r.is_timeout]
                
                if successful_results and hasattr(successful_results[0], 'total_test_time'):
                    total_time = successful_results[0].total_test_time
                    qps = len(successful_results) / total_time
                    avg_response_time = statistics.mean([r.response_time for r in successful_results])
                    
                    concurrent_results[test_type] = {
                        'qps': qps,
                        'avg_response_time': avg_response_time,
                        'success_rate': len(successful_results) / len(test_results) * 100,
                        'timeout_rate': len(timeout_results) / len(test_results) * 100,
                        'total_time': total_time
                    }
            
            analysis_results[concurrent] = concurrent_results
        
        # 打印并发度分析总结
        for test_type in test_types:
            print(f"\n{'='*80}")
            print(f"并发度分析总结 - {test_type}请求")
            print(f"{'='*80}")
            
            if self.max_response_time:
                print(f"{'并发度':<8} {'QPS':<10} {'平均响应时间(秒)':<15} {'成功率(%)':<10} {'超时率(%)':<10} {'总时间(秒)':<10}")
                print("-" * 80)
                
                for concurrent in sorted(analysis_results.keys()):
                    if test_type in analysis_results[concurrent]:
                        result = analysis_results[concurrent][test_type]
                        print(f"{concurrent:<8} {result['qps']:<10.2f} {result['avg_response_time']:<15.3f} {result['success_rate']:<10.1f} {result['timeout_rate']:<10.1f} {result['total_time']:<10.2f}")
            else:
                print(f"{'并发度':<8} {'QPS':<10} {'平均响应时间(秒)':<15} {'成功率(%)':<10} {'总时间(秒)':<10}")
                print("-" * 60)
                
                for concurrent in sorted(analysis_results.keys()):
                    if test_type in analysis_results[concurrent]:
                        result = analysis_results[concurrent][test_type]
                        print(f"{concurrent:<8} {result['qps']:<10.2f} {result['avg_response_time']:<15.3f} {result['success_rate']:<10.1f} {result['total_time']:<10.2f}")
            
            # 分析性能趋势
            print(f"\n{test_type}请求性能分析:")
            qps_values = []
            for concurrent in sorted(analysis_results.keys()):
                if test_type in analysis_results[concurrent]:
                    qps_values.append(analysis_results[concurrent][test_type]['qps'])
            
            if len(qps_values) > 1:
                if qps_values[-1] > qps_values[0]:
                    print(f"  - QPS随并发度增加而提升，系统可能还有余量")
                elif qps_values[-1] < qps_values[0] * 0.8:
                    print(f"  - QPS随并发度增加而下降，可能存在性能瓶颈")
                else:
                    print(f"  - QPS相对稳定，系统性能较为均衡")
        
        # 综合性能对比
        if len(test_types) > 1:
            print(f"\n{'='*80}")
            print("多类型性能对比")
            print(f"{'='*80}")
            print(f"{'测试类型':<12} {'最佳并发度':<12} {'最高QPS':<10} {'平均响应时间(秒)':<15}")
            print("-" * 80)
            
            for test_type in test_types:
                best_concurrent = None
                best_qps = 0
                best_avg_time = 0
                
                for concurrent in sorted(analysis_results.keys()):
                    if test_type in analysis_results[concurrent]:
                        result = analysis_results[concurrent][test_type]
                        if result['qps'] > best_qps:
                            best_qps = result['qps']
                            best_concurrent = concurrent
                            best_avg_time = result['avg_response_time']
                
                if best_concurrent is not None:
                    print(f"{test_type:<12} {best_concurrent:<12} {best_qps:<10.2f} {best_avg_time:<15.3f}")
        
        return analysis_results
    
    def save_results_to_file(self, text_results, audio_results, multimodal_results):
        """保存结果到文件"""
        timestamp = int(time.time())
        filename = f"pressure_test_results_{timestamp}.json"
        
        results_data = {
            "test_info": {
                "host": self.host,
                "port": self.port,
                "model": self.model,
                "timestamp": timestamp
            },
            "text_results": [
                {
                    "success": r.success,
                    "response_time": r.response_time,
                    "error_message": r.error_message,
                    "response_content": r.response_content[:100] + "..." if len(r.response_content) > 100 else r.response_content,
                    "is_timeout": r.is_timeout
                } for r in text_results
            ],
            "audio_results": [
                {
                    "success": r.success,
                    "response_time": r.response_time,
                    "error_message": r.error_message,
                    "response_content": r.response_content[:100] + "..." if len(r.response_content) > 100 else r.response_content,
                    "is_timeout": r.is_timeout
                } for r in audio_results
            ],
            "multimodal_results": [
                {
                    "success": r.success,
                    "response_time": r.response_time,
                    "error_message": r.error_message,
                    "response_content": r.response_content[:100] + "..." if len(r.response_content) > 100 else r.response_content,
                    "is_timeout": r.is_timeout
                } for r in multimodal_results
            ]
        }
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(results_data, f, ensure_ascii=False, indent=2)
        
        print(f"\n详细结果已保存到: {filename}")


def main():
    parser = ArgumentParser(
        description='vLLM 多模态模型压力测试工具'
    )
    parser.add_argument("--host", type=str, default="localhost", help="FastAPI server host")
    parser.add_argument("--port", type=int, default=8081, help="FastAPI server port")
    parser.add_argument("--model", type=str, default="/models", help="Model name")
    parser.add_argument("--requests", type=int, default=100, help="总请求数")
    parser.add_argument("--concurrent", type=int, default=10, help="并发数")
    parser.add_argument("--test-type", type=str, default="all", 
                       choices=["text", "audio", "multimodal", "all", "concurrent-analysis"],
                       help="测试类型")
    parser.add_argument("--concurrent-levels", type=str, default="1,5,10,20,30", 
                       help="并发度分析测试的并发级别，用逗号分隔")
    parser.add_argument("--analysis-test-types", type=str, default="text", 
                       help="并发度分析测试的测试类型，用逗号分隔，可选: text,audio,multimodal")
    parser.add_argument("--max-response-time", type=float, default=None,
                       help="最大响应时间（秒），超过此时间的请求将被统计为超时失败")
    
    args = parser.parse_args()
    
    # 创建压力测试器
    tester = PressureTester(args.host, args.port, args.model, max_response_time=args.max_response_time)
    
    if args.test_type == "all":
        # 运行综合测试
        tester.run_comprehensive_test(args.requests, args.concurrent)
    elif args.test_type == "concurrent-analysis":
        # 运行并发度分析测试
        concurrent_levels = [int(x.strip()) for x in args.concurrent_levels.split(',')]
        test_types = [x.strip() for x in args.analysis_test_types.split(',')]
        tester.run_concurrent_analysis(args.requests, concurrent_levels, test_types)
    else:
        # 运行单一类型测试
        print(f"开始 {args.test_type} 压力测试")
        results = tester.run_sync_test(args.test_type, args.requests, args.concurrent)
        tester.print_statistics(results, f"{args.test_type} 请求")


if __name__ == "__main__":
    main()