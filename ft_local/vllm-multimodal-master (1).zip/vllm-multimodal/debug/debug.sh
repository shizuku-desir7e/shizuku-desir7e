CUDA_VISIBLE_DEVICES=7 python test_offline_serving.py
python3 /opt/multimodal/online_serving.py --model_path=/models


# vllm
VLLM_LOGGING_LEVEL=DEBUG VLLM_USE_V1=0 \
    vllm serve /models \
    --chat-template /opt/template_customqwen2audio.jinja \
    --chat-template-content-format openai \
    --quantization fp8 \
    --max-model-len 8192
VLLM_LOGGING_LEVEL=DEBUG VLLM_USE_V1=0 vllm serve Qwen/Qwen2-Audio-7B-Instruct --quantization fp8 --max-model-len 8192