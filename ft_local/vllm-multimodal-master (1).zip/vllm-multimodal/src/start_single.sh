NUMBER_GPU=${NUMBER_GPU:-1}

VLLM_USE_V1=1 \
vllm serve /models \
    --host ${POD_IP} \
    --port 8081 \
    --chat-template /opt/chat_template_qwen3_omni.jinja \
    --chat-template-content-format openai \
    --tensor-parallel-size ${NUMBER_GPU} \
    --quantization fp8 \
    --enable-prefix-caching \
    --trust-remote-code \
    --max-model-len 8192 \
    --enable-log-requests \
    --enable-log-outputs \
    --max-log-len 8192 \
    --uvicorn-log-level info