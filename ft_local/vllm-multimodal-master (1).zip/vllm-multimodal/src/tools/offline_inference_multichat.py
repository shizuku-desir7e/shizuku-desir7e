from io import BytesIO
from urllib.request import urlopen
import librosa, torch, torchaudio
# from transformers import AutoProcessor, AutoModel
from llamafactory.model.speech_encoder.build_model import build_fireasr
from llamafactory.model.speech_encoder.custom_processor import FireASRAudioProcessor
from llamafactory.model.speech_encoder.modeling_custom_qwen2_audio import CustomQwen2AudioForConditionalGeneration
build_fireasr()
import time, os
from glob import glob
from safetensors.torch import load_file, save_file
import json
from torch.cuda.amp import autocast

def load_data(path):
    with open(path, 'r', encoding='utf-8') as file:
        data_lst = json.load(file)
    return  data_lst

def main_process(args):
    ckpt = args.model_dir
    processor = FireASRAudioProcessor.from_pretrained(ckpt)
    model = CustomQwen2AudioForConditionalGeneration.from_pretrained(ckpt, device_map="auto")

    messages = load_data(f'/apdcephfs_qy4/share_1213607/jinziqi/asr_data/mm_test/{args.test_set}/{args.test_file}')
    print(f"test file : /nfs1/jinziqi/mm_test/{args.test_set}/{args.test_file}")
    print(f"Initialized model from ckpt {args.model_dir}")

    output = []

    for roundi in messages:
        outputi = []
        history = []

        # conversation = []
        for item in roundi:
            system_message = item['system_message']
            audio_path = item['speech']
            if len(history) > 0:
                for history_item in history:
                    system_message += "<| User |>" + history_item[0] + "<| Assistant |>" + history_item[
                        1] + "<｜end▁of▁sentence｜>"

            conversation = [{"role": "<|USER|>", "content": [
                {"type": "text", "text": system_message},
                {"type": "audio", "audio": audio_path},
            ]}]

            text = processor.apply_chat_template(conversation, add_generation_prompt=True, tokenize=False)

            print('=' * 10)
            # print("语音query内容： " + chati["messages"][1]["content"])
            audios = []
            for message in conversation:
                if isinstance(message["content"], list):
                    for ele in message["content"]:
                        if ele["type"] == "audio":
                            audio, sr = torchaudio.load(ele["audio"])
                            audio = audio[0].numpy()
                            print('audio size', audio.shape, sr)
                            audios.append(audio)

            inputs = processor(text=text, audios=audios, return_tensors="pt", padding=True, sampling_rate=16000)


            for k in inputs:
                inputs[k] = inputs[k].to("cuda")

            with autocast():
                generate_ids = model.generate(**inputs, max_new_tokens=100)
                response = processor.batch_decode(generate_ids, skip_special_tokens=False, clean_up_tokenization_spaces=False)
                print(response)

            # print(output_text)
            item['new_response'] = response
            item['history'] = copy.deepcopy(history)
            item["new_system"] = system_message
            if 'partner_rsp_nlu' in datai:
                if datai['partner_rsp_nlu'] == "instruction":
                    history.append([datai['query'], datai['response']])
                else:
                    history.append([datai['query'], datai['response0']])
            else:
                history.append([data['query'], data['response0']])

            if len(history) > 5:
                history = history[1:]
            outputi.append(item)

        output.append(outputi)
    return output

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='LLAMA infer')
    parser.add_argument('--test_set', type=str, default="mm_online_test_250617")
    parser.add_argument('--save_tag', default="", required=False)
    parser.add_argument('--model_dir', default='/apdcephfs/share_303556863/jingyulli/checkpoint/', required=False)
    parser.add_argument('--test_file', default="data_ultrachat_multi.json", required=False)

    args = parser.parse_args()

    savefile = main_process(args)

    with open(f'/apdcephfs_qy4/share_1213607/jinziqi/asr_data/mm_test/res/{args.test_set}_test_{os.path.basename(model_dir)}_{args.save_tag}_t06.json', 'w', encoding='utf-8') as f:
        json.dump(savefile, f, ensure_ascii=False, indent=4)
    print(f"/apdcephfs_qy4/share_1213607/jinziqi/asr_data/mm_test/res/{args.test_set}_test_{os.path.basename(model_dir)}_{args.save_tag}_t06.json")

