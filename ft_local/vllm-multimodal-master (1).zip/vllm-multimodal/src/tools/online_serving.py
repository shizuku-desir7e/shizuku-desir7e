from fastapi import FastAPI, UploadFile, File, Form, HTTPException
import json
import asyncio
import torchaudio

app = FastAPI()
preprocessor = CustomQwen2AudioPreprocessor(model_name="path/to/custom_qwen2_audio", custom_transform=custom_mel_transform)
llm = LLM(model="path/to/custom_qwen2_audio", dtype="bfloat16", max_model_len=32768, limit_mm_per_prompt={"audio": 1}, trust_remote_code=True)

@app.post("/v1/chat/completions")
async def chat_completions(messages: str = Form(...), audio: UploadFile = File(None)):
    try:
        messages = json.loads(messages)
        conversation = [
            {"role": msg["role"], "content": [
                {"type": c["type"], c["type"]: c.get("text") or c.get("audio")}
                for c in msg["content"]
            ]} for msg in messages
        ]
        audios = []
        if audio:
            audio_data = await audio.read()
            with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp_file:
                tmp_file.write(audio_data)
                audios.append(await preprocessor.load_audio(tmp_file.name))
                os.unlink(tmp_file.name)
        inputs = await preprocessor.process_batch([conversation])
        sampling_params = SamplingParams(temperature=0.7, max_tokens=512)
        outputs = llm.generate(inputs, sampling_params=sampling_params)
        return {"choices": [{"message": {"role": "assistant", "content": output.outputs[0].text}} for output in outputs]}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)