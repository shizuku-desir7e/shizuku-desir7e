from io import BytesIO
from urllib.request import urlopen
import librosa, torch, torchaudio
# from transformers import AutoProcessor, AutoModel
from llamafactory.model.speech_encoder.build_model import build_fireasr
from llamafactory.model.speech_encoder.custom_processor import FireASRAudioProcessor
from llamafactory.model.speech_encoder.modeling_custom_qwen2_audio import CustomQwen2AudioForConditionalGeneration
build_fireasr()
import time, os
from glob import glob
from safetensors.torch import load_file, save_file

from torch.cuda.amp import autocast

# ckpt = '/apdcephfs/share_303556863/jingyulli/pretrain/deepseek-32B-v0_mine'
ckpt = '/apdcephfs/share_303556863/jingyulli/pretrain/fireasr_deepseek_audio'
processor = FireASRAudioProcessor.from_pretrained(ckpt)
model = CustomQwen2AudioForConditionalGeneration.from_pretrained(ckpt, device_map="auto")


conversation = [
    # {'role': 'system', 'content': 'You are a helpful assistant.'}, 
    {"role": "<|USER|>", "content": [
        {"type": "text", "text": "请将语音转移为文字。"},
        {"type": "audio", "audio": "/apdcephfs_qy3/share_1443437/jingyulli/data/Cgame/speech_16k/7.wav"},
    ]},
]

text = processor.apply_chat_template(conversation, add_generation_prompt=True, tokenize=False)


print('=' * 10)
print(text)
audios = []
for message in conversation:
    if isinstance(message["content"], list):
        for ele in message["content"]:
            if ele["type"] == "audio":
                audio, sr = torchaudio.load(ele["audio"])
                audio = audio[0].numpy()
                print('audio size', audio.shape, sr)
                audios.append(audio)

inputs = processor(text=text, audios=audios, return_tensors="pt", padding=True, sampling_rate=16000)


for k in inputs:
    inputs[k] = inputs[k].to("cuda")

with autocast():
    generate_ids = model.generate(**inputs, max_new_tokens=100)
    # generate_ids = generate_ids[:, inputs.input_ids.size(1):]

    response = processor.batch_decode(generate_ids, skip_special_tokens=False, clean_up_tokenization_spaces=False)
    print(response)
