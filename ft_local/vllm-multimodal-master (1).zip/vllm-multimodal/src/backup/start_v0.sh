GLOO_SOCKET_IFNAME=bond1 \
NCCL_SOCKET_IFNAME=bond1 \
NCCL_IB_DISABLE=0 \
NCCL_IB_HCA=mlx5_bond_1,mlx5_bond_2,mlx5_bond_3,mlx5_bond_4,mlx5_bond_5,mlx5_bond_6,mlx5_bond_7,mlx5_bond_8 \
VLLM_USE_V1=0 \
vllm serve /models \
    --host ${POD_IP} \
    --port 8081 \
    --chat-template /opt/template_customqwen2audio.jinja \
    --chat-template-content-format openai \
    --tensor-parallel-size 8 \
    --quantization fp8 \
    --enable-prefix-caching \
    --enable-chunked-prefill \
    --max-model-len 8192
    # --kv-cache-dtype fp8_e4m3 \