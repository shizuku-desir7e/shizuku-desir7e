NUMBER_GPU=${NUMBER_GPU:-1}

VLLM_USE_V1=0 \
vllm serve /models \
    --host ${POD_IP} \
    --port 8081 \
    --chat-template /opt/template_customqwen2audio.jinja \
    --chat-template-content-format openai \
    --tensor-parallel-size ${NUMBER_GPU} \
    --quantization fp8 \
    --enable-prefix-caching \
    --enable-chunked-prefill \
    --max-model-len 8192
    # --kv-cache-dtype fp8_e4m3 \