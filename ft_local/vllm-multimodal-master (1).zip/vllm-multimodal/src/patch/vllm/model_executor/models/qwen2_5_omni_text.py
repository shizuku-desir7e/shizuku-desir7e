import logging
import os
import time
import warnings
from collections.abc import Iterable, Mapping, Sequence
from typing import Any, Optional, TypedDict, Union

import torch
import torch.nn as nn
from transformers import BatchFeature

# Performance profiling flag - set VLLM_PROFILE_AUDIO=1 to enable
_PROFILE_AUDIO = os.getenv("VLLM_PROFILE_AUDIO", "0") == "1"
if _PROFILE_AUDIO:
    print(f"[PERF-INIT] Performance profiling enabled", flush=True)
from transformers.models.qwen2_5_omni.processing_qwen2_5_omni import (
    Qwen2_5OmniProcessor,
)
from transformers.models.whisper import WhisperFeatureExtractor

from llamafactory.model.qwen25_omni_speech_encoder.build_model import (
    build_qwen25_omni_text,
)
from llamafactory.model.qwen25_omni_speech_encoder.modeling_qwen25_omni_text import (
    Qwen25OmniTextConfig,
    Qwen2_5OmniAudioEncoder,
    Qwen2AudioMultiModalProjector,
)

build_qwen25_omni_text()

from vllm import envs
from vllm.config import VllmConfig
from vllm.model_executor.sampling_metadata import SamplingMetadata
from vllm.multimodal import MULTIMODAL_REGISTRY
from vllm.multimodal.inputs import (
    MultiModalDataDict,
    MultiModalFieldConfig,
    MultiModalKwargs,
    MultiModalKwargsItem,
)
from vllm.multimodal.parse import MultiModalDataItems, MultiModalDataParser
from vllm.multimodal.processing import (
    BaseProcessingInfo,
    BaseMultiModalProcessor,
    PromptReplacement,
    PromptUpdate,
    PromptUpdateDetails,
)
from vllm.multimodal.profiling import BaseDummyInputsBuilder
from vllm.sequence import IntermediateTensors

from .interfaces import MultiModalEmbeddings, SupportsMultiModal, SupportsPP
from .utils import (
    AutoWeightsLoader,
    init_vllm_registered_model,
    maybe_prefix,
    merge_multimodal_embeddings,
)

logger = logging.getLogger(__name__)


class _TimingContext:
    """Context manager for timing operations when profiling is enabled."""
    def __init__(self, name: str):
        self.name = name
        self.start_time = None
        
    def __enter__(self):
        if _PROFILE_AUDIO:
            self.start_time = time.perf_counter()
        return self
        
    def __exit__(self, exc_type, exc_val, exc_tb):
        if _PROFILE_AUDIO and self.start_time is not None:
            elapsed = time.perf_counter() - self.start_time
            print(f"[PERF] {self.name}: {elapsed*1000:.2f}ms", flush=True)


def _get_feat_extract_output_lengths(input_lengths: torch.Tensor):
    feat_lengths = (input_lengths - 1) // 2 + 1
    output_lengths = (feat_lengths - 2) // 2 + 1
    return feat_lengths, output_lengths


class Qwen25OmniTextAudioInputs(TypedDict):
    input_features: torch.Tensor
    feature_attention_mask: torch.Tensor


class Qwen25OmniTextProcessingInfo(BaseProcessingInfo):

    def get_hf_config(self):
        return self.ctx.get_hf_config(Qwen25OmniTextConfig)

    def get_hf_processor(
        self,
        *,
        sampling_rate: Optional[int] = None,
        **kwargs: object,
    ) -> Qwen2_5OmniProcessor:
        # For audio-only models, we need to handle the case where image_processor
        # is not available. Try to load processor, but if it fails due to
        # missing image_processor, we'll create a minimal processor wrapper.
        try:
            return self.ctx.get_hf_processor(
                Qwen2_5OmniProcessor, use_fast=kwargs.pop("use_fast", True), **kwargs
            )
        except ValueError as e:
            # If the error is about missing image_processor, try to load
            # only the feature_extractor and tokenizer, then create a minimal processor
            if "image_processor" in str(e).lower() or "Unrecognized image processor" in str(e):
                import logging
                logger = logging.getLogger(__name__)
                logger.warning(
                    f"Failed to load Qwen2_5OmniProcessor due to missing image_processor: {e}. "
                    "Creating minimal processor with only feature_extractor and tokenizer."
                )
                # Load feature_extractor and tokenizer separately
                from transformers.models.whisper import WhisperFeatureExtractor
                from transformers import AutoTokenizer
                
                model_path = self.ctx.model_config.model
                feature_extractor = WhisperFeatureExtractor.from_pretrained(
                    model_path,
                    trust_remote_code=self.ctx.model_config.trust_remote_code,
                )
                tokenizer = AutoTokenizer.from_pretrained(
                    model_path,
                    trust_remote_code=self.ctx.model_config.trust_remote_code,
                )
                
                # Create a minimal processor-like object that mimics Qwen2_5OmniProcessor
                class MinimalProcessor:
                    def __init__(self, feature_extractor, tokenizer):
                        self.feature_extractor = feature_extractor
                        self.tokenizer = tokenizer
                        self.audio_token = "<|AUDIO|>"
                        self.audio_bos_token = "<|audio_bos|>"
                        self.audio_eos_token = "<|audio_eos|>"
                    
                    def __call__(self, text=None, audio=None, return_tensors=None, **kwargs):
                        """
                        Mimic Qwen2_5OmniProcessor.__call__ for audio-only processing.
                        """
                        from transformers import BatchFeature
                        
                        result = {}
                        
                        # Separate kwargs for tokenizer and feature_extractor
                        # sampling_rate is for feature_extractor only
                        sampling_rate = kwargs.pop('sampling_rate', None)
                        
                        # Common kwargs that both can accept
                        common_kwargs = {}
                        if return_tensors is not None:
                            common_kwargs['return_tensors'] = return_tensors
                        
                        # Tokenizer-specific kwargs (remove audio-related ones)
                        tokenizer_kwargs = {k: v for k, v in kwargs.items() 
                                          if k not in ['sampling_rate', 'audio']}
                        tokenizer_kwargs.update(common_kwargs)
                        
                        # Feature extractor-specific kwargs
                        feature_extractor_kwargs = dict(kwargs)
                        if sampling_rate is not None:
                            feature_extractor_kwargs['sampling_rate'] = sampling_rate
                        feature_extractor_kwargs.update(common_kwargs)
                        
                        # Process text with tokenizer
                        if text is not None:
                            if isinstance(text, str):
                                text = [text]
                            tokenizer_output = self.tokenizer(text, **tokenizer_kwargs)
                            result.update(tokenizer_output)
                        
                        # Process audio with feature_extractor
                        if audio is not None:
                            if not isinstance(audio, list):
                                audio = [audio]
                            feature_extractor_output = self.feature_extractor(
                                audio, **feature_extractor_kwargs
                            )
                            result.update(feature_extractor_output)
                        
                        return BatchFeature(result, tensor_type=return_tensors)
                
                return MinimalProcessor(feature_extractor, tokenizer)  # type: ignore
            else:
                raise

    def get_feature_extractor(
        self,
        *,
        sampling_rate: Optional[int] = None,
    ) -> WhisperFeatureExtractor:
        hf_processor = self.get_hf_processor(sampling_rate=sampling_rate)
        feature_extractor = hf_processor.feature_extractor  # type: ignore
        assert isinstance(feature_extractor, WhisperFeatureExtractor)
        return feature_extractor

    def get_supported_mm_limits(self) -> Mapping[str, Optional[int]]:
        return {"audio": None}


class Qwen25OmniTextDummyInputsBuilder(
    BaseDummyInputsBuilder[Qwen25OmniTextProcessingInfo]
):

    def get_dummy_text(self, mm_counts: Mapping[str, int]) -> str:
        num_audios = mm_counts.get("audio", 0)
        processor = self.info.get_hf_processor()
        return processor.audio_token * num_audios

    def get_dummy_mm_data(
        self,
        seq_len: int,
        mm_counts: Mapping[str, int],
    ) -> MultiModalDataDict:
        feature_extractor = self.info.get_feature_extractor()
        # Minimize dummy audio length for profiling to reduce memory usage
        # Use only 1 second of audio (16000 samples at 16kHz) instead of full chunk_length
        # This significantly reduces memory usage during profiling
        audio_len = min(
            feature_extractor.chunk_length * feature_extractor.sampling_rate,
            feature_extractor.sampling_rate  # 1 second max
        )
        num_audios = mm_counts.get("audio", 0)
        return {"audio": self._get_dummy_audios(length=audio_len, num_audios=num_audios)}


class Qwen25OmniTextMultiModalProcessor(
    BaseMultiModalProcessor[Qwen25OmniTextProcessingInfo]
):

    def _get_data_parser(self) -> MultiModalDataParser:
        feature_extractor = self.info.get_feature_extractor()
        return MultiModalDataParser(target_sr=feature_extractor.sampling_rate)

    def _call_hf_processor(
        self,
        prompt: str,
        mm_data: Mapping[str, object],
        mm_kwargs: Mapping[str, Any],
        tok_kwargs: Mapping[str, object],
    ) -> BatchFeature:
        logger.debug("Starting to call HF processor")
        try:
            data = dict(mm_data)
            audios = data.pop("audios", [])
            if audios:
                data["audio"] = audios

            if not data.get("audio", []):
                prompt_ids = self.info.get_tokenizer().encode(prompt)
                prompt_ids = self._apply_hf_processor_tokens_only(prompt_ids)
                return BatchFeature(dict(input_ids=[prompt_ids]), tensor_type="pt")

            feature_extractor = self.info.get_feature_extractor(**mm_kwargs)
            mm_kwargs = dict(**mm_kwargs, sampling_rate=feature_extractor.sampling_rate)
            result = super()._call_hf_processor(
                prompt=prompt,
                mm_data=data,
                mm_kwargs=mm_kwargs,
                tok_kwargs=tok_kwargs,
            )
            if "input_features" in result:
                input_features = result["input_features"]
                if "feature_attention_mask" not in result:
                    attention_mask = result.get("attention_mask")
                    feature_attention_mask: torch.Tensor
                    try:
                        seq_len = input_features.shape[-1] if hasattr(input_features, "shape") else None
                        if attention_mask is not None:
                            feature_attention_mask = attention_mask.to(dtype=torch.long)
                            if feature_attention_mask.dim() == 3:
                                feature_attention_mask = feature_attention_mask.squeeze(1)
                            if feature_attention_mask.dim() == 1:
                                feature_attention_mask = feature_attention_mask.unsqueeze(-1)
                            if seq_len is not None and feature_attention_mask.shape[-1] != seq_len:
                                mask_len = feature_attention_mask.shape[-1]
                                if mask_len > seq_len:
                                    feature_attention_mask = feature_attention_mask[..., :seq_len]
                                else:
                                    pad_amount = seq_len - mask_len
                                    feature_attention_mask = torch.nn.functional.pad(
                                        feature_attention_mask, (0, pad_amount), value=0
                                    )
                        else:
                            batch_size = input_features.shape[0]
                            seq_len = input_features.shape[-1]
                            device = input_features.device if hasattr(input_features, "device") else None
                            dtype = torch.long
                            feature_attention_mask = torch.ones(
                                batch_size,
                                seq_len,
                                dtype=dtype,
                                device=device,
                            )
                    except Exception as mask_err:
                        logger.error(f"Failed to generate feature_attention_mask: {mask_err}", exc_info=True)
                        raise

                    result["feature_attention_mask"] = feature_attention_mask
            return result
        except Exception as e:
            logger.error(f"Call failed: {e}", exc_info=True)
            raise

    def _hf_processor_applies_updates(
        self,
        prompt_text: str,
        mm_items: MultiModalDataItems,
        hf_processor_mm_kwargs: Mapping[str, object],
        tokenization_kwargs: Mapping[str, object],
    ) -> bool:
        return False

    def _get_mm_fields_config(
        self,
        hf_inputs: BatchFeature,
        hf_processor_mm_kwargs: Mapping[str, object],
    ) -> Mapping[str, MultiModalFieldConfig]:
        try:
            return dict(
                input_features=MultiModalFieldConfig.batched("audio"),
                feature_attention_mask=MultiModalFieldConfig.batched("audio"),
            )
        except Exception as e:
            logger.error(f"Failed to get config: {e}", exc_info=True)
            raise

    def _get_prompt_updates(
        self,
        mm_items: MultiModalDataItems,
        hf_processor_mm_kwargs: Mapping[str, object],
        out_mm_kwargs: MultiModalKwargs,
    ) -> Sequence[PromptUpdate]:
        try:
            processor = self.info.get_hf_processor(**hf_processor_mm_kwargs)
            tokenizer = self.info.get_tokenizer()
            vocab = tokenizer.get_vocab()

            audio_token = getattr(processor, "audio_token", "<|AUDIO|>")
            audio_bos_token = getattr(processor, "audio_bos_token", "<|audio_bos|>")
            audio_eos_token = getattr(processor, "audio_eos_token", "<|audio_eos|>")

            audio_token_id = vocab[audio_token]
            audio_bos_id = vocab[audio_bos_token]
            audio_eos_id = vocab[audio_eos_token]

            feature_attention_mask = out_mm_kwargs.get("feature_attention_mask")
            
            if feature_attention_mask is None and "audio" in out_mm_kwargs:
                try:
                    audio_items = out_mm_kwargs["audio"]
                    fam_list = []
                    for item in audio_items:
                        if isinstance(item, MultiModalKwargsItem):
                            data_dict = item.get_data()
                            fam_tensor = data_dict.get("feature_attention_mask")
                            if fam_tensor is None:
                                continue
                            fam_tensor = fam_tensor if fam_tensor.dim() == 1 else fam_tensor.view(-1)
                            fam_list.append(fam_tensor)
                    if len(fam_list) > 0:
                        feature_attention_mask = torch.stack(fam_list, dim=0)
                except Exception as err:  # pragma: no cover - best effort logging
                    logger.debug(f"normalize nested feature_attention_mask failed: {err}", exc_info=True)

            if feature_attention_mask is None:
                audio_output_lengths: list[int] = []
            else:
                assert isinstance(feature_attention_mask, torch.Tensor)
                feature_lens_sum = feature_attention_mask.sum(-1)
                _, audio_output_lens = _get_feat_extract_output_lengths(feature_lens_sum)
                audio_output_lengths = audio_output_lens.tolist()

            def get_replacement_qwen25_audio(item_idx: int):
                if audio_output_lengths:
                    safe_idx = min(item_idx, len(audio_output_lengths) - 1)
                    if item_idx >= len(audio_output_lengths):
                        warnings.warn(
                            "Requested audio item index %s exceeds available lengths %s. "
                            "Falling back to last valid index %s." % (item_idx, len(audio_output_lengths), safe_idx)
                        )
                    num_features = audio_output_lengths[safe_idx]
                else:
                    num_features = 1

                if num_features == 0:
                    audios = mm_items.get_items("audio")
                    error_msg = f"The audio (len={audios.get_audio_length(item_idx)}) is too short to be represented inside the model"  # type: ignore[attr-defined]
                    raise ValueError(error_msg)

                audio_tokens = [audio_token_id] * num_features
                return PromptUpdateDetails.select_token_id(
                    [audio_bos_id] + audio_tokens + [audio_eos_id],
                    embed_token_id=audio_token_id,
                )

            return [
                PromptReplacement(
                    modality="audio",
                    target=audio_token,
                    replacement=get_replacement_qwen25_audio,
                )
            ]
        except Exception as e:
            logger.error(f"Failed to get prompt updates: {e}", exc_info=True)
            raise


@MULTIMODAL_REGISTRY.register_processor(
    Qwen25OmniTextMultiModalProcessor,
    info=Qwen25OmniTextProcessingInfo,
    dummy_inputs=Qwen25OmniTextDummyInputsBuilder,
)
class Qwen25OmniTextForConditionalGeneration(nn.Module, SupportsMultiModal, SupportsPP):

    @classmethod
    def get_placeholder_str(cls, modality: str, i: int) -> Optional[str]:
        if modality.startswith("audio"):
            return f"Audio {i}: <|audio_bos|><|AUDIO|><|audio_eos|>"
        raise ValueError("Only audio modality is supported")

    def __init__(self, *, vllm_config: VllmConfig, prefix: str = ""):
        import logging
        logger = logging.getLogger(__name__)
        logger.info("[Qwen25OmniTextForConditionalGeneration.__init__] Starting initialization")
        
        super().__init__()
        logger.info("[Qwen25OmniTextForConditionalGeneration.__init__] super().__init__() completed")
        
        try:
            logger.info("[Qwen25OmniTextForConditionalGeneration.__init__] Getting config from vllm_config")
            config = vllm_config.model_config.hf_config
            logger.info(f"[Qwen25OmniTextForConditionalGeneration.__init__] Config type: {type(config)}, model_type: {getattr(config, 'model_type', 'unknown')}")
            
            quant_config = vllm_config.quant_config
            self.config = config
            self.multimodal_config = vllm_config.model_config.multimodal_config
            logger.info("[Qwen25OmniTextForConditionalGeneration.__init__] Config assigned to self")

            # Ensure sub-configs are fully initialized before serialization
            # This prevents _LazyConfigMapping serialization errors in multiprocessing
            logger.info("[Qwen25OmniTextForConditionalGeneration.__init__] Accessing audio_config")
            audio_config = config.audio_config
            logger.info(f"[Qwen25OmniTextForConditionalGeneration.__init__] audio_config type: {type(audio_config)}")
            
            logger.info("[Qwen25OmniTextForConditionalGeneration.__init__] Accessing text_config")
            text_config = config.text_config
            logger.info(f"[Qwen25OmniTextForConditionalGeneration.__init__] text_config type: {type(text_config)}")
            
            # Ensure audio_config and text_config are fully loaded (not lazy)
            logger.info("[Qwen25OmniTextForConditionalGeneration.__init__] Forcing initialization of audio_config")
            if hasattr(audio_config, '__dict__'):
                # Force initialization by accessing all attributes
                _ = audio_config.__dict__
                logger.info(f"[Qwen25OmniTextForConditionalGeneration.__init__] audio_config.__dict__ accessed, keys: {list(audio_config.__dict__.keys())[:10]}")
            
            logger.info("[Qwen25OmniTextForConditionalGeneration.__init__] Forcing initialization of text_config")
            if hasattr(text_config, '__dict__'):
                # Force initialization by accessing all attributes
                _ = text_config.__dict__
                logger.info(f"[Qwen25OmniTextForConditionalGeneration.__init__] text_config.__dict__ accessed, keys: {list(text_config.__dict__.keys())[:10]}")
            
            # Check if sub_configs property exists and access it
            logger.info("[Qwen25OmniTextForConditionalGeneration.__init__] Checking sub_configs property")
            if hasattr(config, 'sub_configs'):
                try:
                    sub_configs = config.sub_configs
                    logger.info(f"[Qwen25OmniTextForConditionalGeneration.__init__] sub_configs accessed successfully: {type(sub_configs)}")
                except Exception as e:
                    logger.error(f"[Qwen25OmniTextForConditionalGeneration.__init__] Error accessing sub_configs: {e}", exc_info=True)
            
        except Exception as e:
            logger.error(f"[Qwen25OmniTextForConditionalGeneration.__init__] Error before audio_tower initialization: {e}", exc_info=True)
            raise
        
        # Initialize audio tower with audio_config
        try:
            logger.info("[Qwen25OmniTextForConditionalGeneration.__init__] Initializing audio_tower")
            # Enable flash_attention_2 for audio_config to avoid creating large attention masks
            # This prevents OOM when processing long audio sequences
            try:
                import flash_attn  # type: ignore
                audio_config._attn_implementation_autoset = True
                audio_config._attn_implementation = "flash_attention_2"
                logger.info("[Qwen25OmniTextForConditionalGeneration.__init__] Enabled flash_attention_2 for audio_tower")
            except (ImportError, AttributeError):
                logger.warning("[Qwen25OmniTextForConditionalGeneration.__init__] flash_attn not available, using default attention")
            
            self.audio_tower = Qwen2_5OmniAudioEncoder(audio_config)
            logger.info("[Qwen25OmniTextForConditionalGeneration.__init__] audio_tower initialized successfully")
        except Exception as e:
            logger.error(f"[Qwen25OmniTextForConditionalGeneration.__init__] Error initializing audio_tower: {e}", exc_info=True)
            raise
        self.audio_tower.to(self.audio_tower.conv1.weight.device)
        # Move positional_embedding to the correct device and dtype
        if hasattr(self.audio_tower, "positional_embedding"):
            self.audio_tower.positional_embedding.to(
                dtype=self.audio_tower.conv1.weight.dtype,
                device=self.audio_tower.conv1.weight.device
            )
        # Move layers to the correct device and dtype
        if hasattr(self.audio_tower, "layers"):
            for layer in self.audio_tower.layers:
                layer.to(
                    dtype=self.audio_tower.conv1.weight.dtype,
                    device=self.audio_tower.conv1.weight.device
                )
        try:
            logger.info("[Qwen25OmniTextForConditionalGeneration.__init__] Initializing multi_modal_projector")
            self.multi_modal_projector = Qwen2AudioMultiModalProjector(config)
            logger.info("[Qwen25OmniTextForConditionalGeneration.__init__] multi_modal_projector initialized")

            self.quant_config = quant_config
            logger.info("[Qwen25OmniTextForConditionalGeneration.__init__] Initializing language_model")
            self.language_model = init_vllm_registered_model(
                vllm_config=vllm_config,
                hf_config=config.text_config,
                prefix=maybe_prefix(prefix, "language_model"),
                architectures=["Qwen2ForCausalLM"],
            )
            logger.info("[Qwen25OmniTextForConditionalGeneration.__init__] language_model initialized")
            
            self.make_empty_intermediate_tensors = (
                self.language_model.make_empty_intermediate_tensors
            )

            self.pad_token_id = self.config.pad_token_id if self.config.pad_token_id is not None else -1
            self._padding_side = "left"
            logger.info("[Qwen25OmniTextForConditionalGeneration.__init__] Initialization completed successfully")
        except Exception as e:
            logger.error(f"[Qwen25OmniTextForConditionalGeneration.__init__] Error during final initialization: {e}", exc_info=True)
            raise

    def _validate_and_reshape_mm_tensor(
        self,
        mm_input: object,
        name: str,
    ) -> torch.Tensor:
        if not isinstance(mm_input, (torch.Tensor, list)):
            raise ValueError(f"Incorrect type of {name}. Got type: {type(mm_input)}")
        if isinstance(mm_input, torch.Tensor):
            return torch.concat(list(mm_input))
        return torch.concat(mm_input)

    def _parse_and_validate_audio_input(
        self,
        **kwargs: object,
    ) -> Optional[Qwen25OmniTextAudioInputs]:
        input_features = kwargs.pop("input_features", None)
        feature_attention_mask = kwargs.pop("feature_attention_mask", None)
        
        if input_features is None:
            return None
        
        try:
            input_features = self._validate_and_reshape_mm_tensor(input_features, "input_features")
        except Exception as e:
            logger.error(f"Failed to validate input_features: {e}", exc_info=True)
            raise
        
        # Handle None feature_attention_mask by creating a default mask from input_features shape
        if feature_attention_mask is None:
            # If input_features is a tensor, create a mask based on its shape
            if isinstance(input_features, torch.Tensor):
                # input_features shape: (batch_size, num_mel_bins, max_seq_len)
                if input_features.dim() == 3:
                    batch_size, num_mel_bins, max_seq_len = input_features.shape
                    # Minimize max_seq_len for profiling to reduce memory usage
                    # Use only 500 frames max (about 5 seconds at 16kHz with hop_length=160)
                    max_reasonable_seq_len = min(max_seq_len, 500)
                    # Create a mask where all positions are valid (all ones)
                    feature_attention_mask = torch.ones(
                        batch_size, max_reasonable_seq_len,
                        dtype=torch.long,
                        device=input_features.device
                    )
                    # If we truncated, also truncate input_features to match
                    if max_seq_len > max_reasonable_seq_len:
                        input_features = input_features[:, :, :max_reasonable_seq_len]
                else:
                    # If shape is unexpected, create a simple mask with minimal size
                    feature_attention_mask = torch.ones(
                        input_features.shape[0] if input_features.dim() > 0 else 1,
                        min(input_features.shape[-1] if input_features.dim() > 1 else input_features.shape[0], 500),
                        dtype=torch.long,
                        device=input_features.device
                    )
            else:
                # If input_features is a list, we need to process it differently
                raise ValueError(
                    "feature_attention_mask is None and input_features is a list. "
                    "Please provide feature_attention_mask explicitly."
                )
        else:
            try:
                feature_attention_mask = self._validate_and_reshape_mm_tensor(
                    feature_attention_mask, "feature_attention_mask"
                )
            except Exception as e:
                logger.error(f"Failed to validate feature_attention_mask: {e}", exc_info=True)
                raise
        
        if not isinstance(input_features, (torch.Tensor, list)):
            error_msg = f"Incorrect type of audio input features. Got type: {type(input_features)}"
            raise ValueError(error_msg)
        
        return Qwen25OmniTextAudioInputs(
            input_features=input_features,
            feature_attention_mask=feature_attention_mask,
        )

    def _process_audio_input(self, audio_input: Qwen25OmniTextAudioInputs):
        if envs.VLLM_USE_V1:
            return self._process_audio_input_v1(audio_input)

        with _TimingContext("_process_audio_input"):
            input_features_ = audio_input["input_features"]
            feature_attention_mask = audio_input["feature_attention_mask"]

            with _TimingContext("calculate_feature_lengths"):
                # Calculate feature lengths
                feature_lens = feature_attention_mask.sum(-1)
                (
                    audio_feat_lengths,
                    audio_output_lengths,
                ) = self.audio_tower._get_feat_extract_output_lengths(feature_lens)

            # Prepare input features: Qwen2_5OmniAudioEncoder expects (num_mel_bins, seq_len)
            batch_size, num_mel_bins, max_seq_len = input_features_.shape
            
            with _TimingContext("prepare_input_features"):
                # Optimize: avoid creating intermediate list, use direct indexing
                # Pre-compute cumulative lengths for efficient concatenation
                feature_lens_cumsum = torch.cumsum(feature_lens, dim=0)
                total_len = feature_lens_cumsum[-1].item()
                
                # Pre-allocate output tensor
                target_dtype = self.audio_tower.conv1.weight.dtype
                target_device = self.audio_tower.conv1.weight.device
                input_features = torch.zeros(
                    num_mel_bins, total_len,
                    dtype=target_dtype,
                    device=target_device
                )
                
                # Copy slices directly into pre-allocated tensor
                start_idx = 0
                for i in range(batch_size):
                    end_idx = start_idx + feature_lens[i].item()
                    input_features[:, start_idx:end_idx] = input_features_[i, :, :feature_lens[i].item()].to(
                        dtype=target_dtype, device=target_device
                    )
                    start_idx = end_idx
                
                feature_lens_tensor = feature_lens.to(torch.long)
                aftercnn_lens_tensor = audio_feat_lengths

            with _TimingContext("audio_tower_forward"):
                # Call audio tower with no_grad for inference
                with torch.no_grad():
                    audio_outputs = self.audio_tower(
                        input_features,
                        feature_lens=feature_lens_tensor,
                        aftercnn_lens=aftercnn_lens_tensor,
                    )
            
            with _TimingContext("project_and_reshape"):
                # Extract hidden states and project
                audio_hidden_states = audio_outputs.last_hidden_state  # (total_tokens, d_model)
                audio_features = self.multi_modal_projector(audio_hidden_states)  # (total_tokens, text_hidden_size)
                
                # Reshape to (batch_size, max_audio_tokens, embed_dim)
                # Optimize: use more efficient padding with pad_sequence
                audio_output_lengths_list = audio_output_lengths.tolist()
                audio_features_list = audio_features.split(audio_output_lengths_list, dim=0)
                max_audio_tokens = max(len(f) for f in audio_features_list) if audio_features_list else 0
                embed_dim = audio_features.shape[-1]
                
                # Optimize padding: use pad_sequence for better performance
                if max_audio_tokens > 0:
                    # Use pad_sequence which is more efficient than manual padding
                    from torch.nn.utils.rnn import pad_sequence
                    audio_features_batched = pad_sequence(
                        audio_features_list,
                        batch_first=True,
                        padding_value=0.0
                    )
                else:
                    audio_features_batched = torch.empty(0, 0, embed_dim, device=audio_features.device, dtype=audio_features.dtype)
            
            return audio_features_batched, audio_output_lengths

    def _process_audio_input_v1(self, audio_input: Qwen25OmniTextAudioInputs):
        with _TimingContext("_process_audio_input_v1"):
            input_features_ = audio_input["input_features"]
            feature_attention_mask = audio_input["feature_attention_mask"]

            with _TimingContext("calculate_feature_lengths_v1"):
                # Calculate feature lengths
                feature_lens = feature_attention_mask.sum(-1)
                feature_attention_mask_sum = feature_lens
                (
                    audio_feat_lengths,
                    audio_output_lengths,
                ) = self.audio_tower._get_feat_extract_output_lengths(feature_attention_mask_sum)
                
                (
                    _,
                    audio_output_expected_lengths,
                ) = _get_feat_extract_output_lengths(feature_attention_mask_sum)

            # Prepare input features: Qwen2_5OmniAudioEncoder expects (num_mel_bins, seq_len)
            batch_size, num_mel_bins, max_seq_len = input_features_.shape
            
            with _TimingContext("prepare_input_features_v1"):
                # Optimize: avoid creating intermediate list, use direct indexing
                feature_lens_cumsum = torch.cumsum(feature_lens, dim=0)
                total_len = feature_lens_cumsum[-1].item()
                
                # Pre-allocate output tensor
                target_dtype = self.audio_tower.conv1.weight.dtype
                target_device = self.audio_tower.conv1.weight.device
                input_features = torch.zeros(
                    num_mel_bins, total_len,
                    dtype=target_dtype,
                    device=target_device
                )
                
                # Copy slices directly into pre-allocated tensor
                start_idx = 0
                for i in range(batch_size):
                    end_idx = start_idx + feature_lens[i].item()
                    input_features[:, start_idx:end_idx] = input_features_[i, :, :feature_lens[i].item()].to(
                        dtype=target_dtype, device=target_device
                    )
                    start_idx = end_idx
                
                feature_lens_tensor = feature_lens.to(torch.long)
                aftercnn_lens_tensor = audio_feat_lengths

            with _TimingContext("audio_tower_forward_v1"):
                # Call audio tower with no_grad for inference
                with torch.no_grad():
                    audio_outputs = self.audio_tower(
                        input_features,
                        feature_lens=feature_lens_tensor,
                        aftercnn_lens=aftercnn_lens_tensor,
                    )
            
            with _TimingContext("project_and_reshape_v1"):
                # Extract hidden states and project
                audio_hidden_states = audio_outputs.last_hidden_state  # (total_tokens, d_model)
                audio_features = self.multi_modal_projector(audio_hidden_states)  # (total_tokens, text_hidden_size)
                
                # Reshape to (batch_size, max_audio_tokens, embed_dim)
                audio_output_lengths_list = audio_output_lengths.tolist()
                audio_features_list = audio_features.split(audio_output_lengths_list, dim=0)
                max_audio_tokens = max(len(f) for f in audio_features_list) if audio_features_list else 0
                embed_dim = audio_features.shape[-1]
                
                # Optimize padding: use pad_sequence for better performance
                if max_audio_tokens > 0:
                    from torch.nn.utils.rnn import pad_sequence
                    audio_features_batched = pad_sequence(
                        audio_features_list,
                        batch_first=True,
                        padding_value=0.0
                    )
                else:
                    audio_features_batched = torch.empty(0, 0, embed_dim, device=audio_features.device, dtype=audio_features.dtype)
            
            return audio_features_batched, audio_output_lengths, audio_output_expected_lengths

    def get_language_model(self) -> torch.nn.Module:
        return self.language_model

    def get_multimodal_embeddings(
        self,
        **kwargs: object,
    ) -> MultiModalEmbeddings:
        if _PROFILE_AUDIO:
            print(f"[PERF] get_multimodal_embeddings called, kwargs keys: {list(kwargs.keys())}", flush=True)
        with _TimingContext("get_multimodal_embeddings"):
            if envs.VLLM_USE_V1:
                return self.get_multimodal_embeddings_v1(**kwargs)

            try:
                with _TimingContext("parse_audio_input"):
                    audio_input = self._parse_and_validate_audio_input(**kwargs)
                if audio_input is None:
                    if _PROFILE_AUDIO:
                        print(f"[PERF] get_multimodal_embeddings: audio_input is None, returning []", flush=True)
                    return []
                return self._process_audio_input(audio_input)
            except Exception as e:
                logger.error(f"Processing failed: {e}", exc_info=True)
                raise

    def get_multimodal_embeddings_v1(
        self,
        **kwargs: object,
    ) -> MultiModalEmbeddings:
        try:
            audio_input = self._parse_and_validate_audio_input(**kwargs)
            if audio_input is None:
                return []

            (
                audio_features,
                audio_output_lengths,
                audio_output_expected_lengths,
            ) = self._process_audio_input_v1(audio_input)
        except Exception as e:
            logger.error(f"Failed to process audio input: {e}", exc_info=True)
            raise

        try:
            num_audios, _, embed_dim = audio_features.shape
            multimodal_embeddings: list[torch.Tensor] = []
            for i in range(num_audios):
                actual_length = audio_output_lengths[i].item()
                expected_length = audio_output_expected_lengths[i].item()
                audio_embedding = audio_features[i, :actual_length, :]
                if actual_length < expected_length:
                    padding_length = expected_length - actual_length
                    padding = torch.zeros(
                        padding_length,
                        embed_dim,
                        device=audio_embedding.device,
                        dtype=audio_embedding.dtype,
                    )
                    audio_embedding = torch.cat([audio_embedding, padding], dim=0)
                elif actual_length > expected_length:
                    audio_embedding = audio_embedding[:expected_length]
                multimodal_embeddings.append(audio_embedding)

            return multimodal_embeddings
        except Exception as e:
            logger.error(f"Failed to build embedding list: {e}", exc_info=True)
            raise

    def get_input_embeddings(
        self,
        input_ids: torch.Tensor,
        multimodal_embeddings: Optional[MultiModalEmbeddings] = None,
    ) -> torch.Tensor:
        if envs.VLLM_USE_V1:
            return self.get_input_embeddings_v1(input_ids, multimodal_embeddings)

        with _TimingContext("get_input_embeddings"):
            try:
                with _TimingContext("get_lm_embeddings"):
                    inputs_embeds = self.language_model.get_input_embeddings(input_ids)
            except Exception as e:
                logger.error(f"Failed to get language model input embeddings: {e}", exc_info=True)
                raise
            
            if multimodal_embeddings is None or len(multimodal_embeddings) == 0:
                return inputs_embeds

            try:
                audio_features, audio_output_lengths = multimodal_embeddings
                num_audios, max_audio_tokens, embed_dim = audio_features.shape
            except Exception as e:
                logger.error(f"Failed to unpack multimodal_embeddings: {e}", exc_info=True)
                raise
            
            with _TimingContext("apply_audio_mask"):
                try:
                    # Optimize: use more efficient masking
                    audio_features_mask = torch.arange(max_audio_tokens, device=audio_output_lengths.device)[
                        None, :
                    ]
                    audio_features_mask = audio_features_mask < audio_output_lengths[:, None]
                    audio_features = audio_features[audio_features_mask]
                except Exception as e:
                    logger.error(f"Failed to apply mask: {e}", exc_info=True)
                    raise

            try:
                n_audio_tokens = (input_ids == self.config.audio_token_index).sum().item()
                n_audio_features = audio_features.shape[0]
            except Exception as e:
                logger.error(f"Failed to calculate audio token count: {e}", exc_info=True)
                raise

            with _TimingContext("adjust_audio_features"):
                try:
                    if n_audio_tokens != n_audio_features:
                        if n_audio_tokens > n_audio_features:
                            # Optimize: avoid creating list in cat
                            last_row = audio_features[-1:, :]
                            padding = last_row.repeat(n_audio_tokens - n_audio_features, 1)
                            audio_features = torch.cat([audio_features, padding], dim=0)
                        else:
                            audio_features = audio_features[:n_audio_tokens]
                except Exception as e:
                    logger.error(f"Failed to adjust audio features count: {e}", exc_info=True)
                    raise

            with _TimingContext("merge_embeddings"):
                try:
                    # Optimize: combine operations
                    special_audio_mask = (input_ids == self.config.audio_token_index)
                    audio_features = audio_features.to(device=inputs_embeds.device, dtype=inputs_embeds.dtype)
                    # Use in-place operation where possible
                    special_audio_mask = special_audio_mask.to(inputs_embeds.device)
                    special_audio_mask = special_audio_mask.unsqueeze(-1).expand_as(inputs_embeds)
                    inputs_embeds = inputs_embeds.masked_scatter(special_audio_mask, audio_features)
                except Exception as e:
                    logger.error(f"Failed to merge embeddings: {e}", exc_info=True)
                    raise
            
            return inputs_embeds

    def get_input_embeddings_v1(
        self,
        input_ids: torch.Tensor,
        multimodal_embeddings: Optional[MultiModalEmbeddings] = None,
    ) -> torch.Tensor:
        try:
            inputs_embeds = self.language_model.get_input_embeddings(input_ids)
        except Exception as e:
            logger.error(f"Failed to get language model input embeddings: {e}", exc_info=True)
            raise
        
        if multimodal_embeddings is not None and len(multimodal_embeddings) != 0:
            try:
                audio_placeholder_mask = (input_ids == self.config.audio_token_index)
                num_audio_tokens = int(audio_placeholder_mask.sum().item())

                if isinstance(multimodal_embeddings, torch.Tensor):
                    flattened_embeddings = multimodal_embeddings
                else:
                    embeddings_list: list[torch.Tensor] = []
                    for emb in multimodal_embeddings:
                        if not isinstance(emb, torch.Tensor):
                            logger.warning(f"multimodal_embeddings item is not a Tensor, skipping: {type(emb)}")
                            continue
                        embeddings_list.append(emb)
                    if not embeddings_list:
                        raise ValueError("multimodal_embeddings is empty or does not contain valid Tensors.")
                    if len(embeddings_list) == 1:
                        flattened_embeddings = embeddings_list[0]
                    else:
                        flattened_embeddings = torch.cat(embeddings_list, dim=0)

                total_audio_features = int(flattened_embeddings.shape[0])

                if num_audio_tokens != total_audio_features:
                    diff = num_audio_tokens - total_audio_features
                    logger.warning(f"Audio token count mismatch with embeddings count, diff = {diff}")
                    if diff > 0:
                        last_row = flattened_embeddings[-1:, :].clone()
                        padding = last_row.repeat(diff, 1)
                        flattened_embeddings = torch.cat(
                            [flattened_embeddings, padding],
                            dim=0,
                        )
                    else:
                        flattened_embeddings = flattened_embeddings[:num_audio_tokens]

                adjusted_multimodal_embeddings: list[torch.Tensor] = [flattened_embeddings]

                inputs_embeds = merge_multimodal_embeddings(
                    input_ids,
                    inputs_embeds,
                    adjusted_multimodal_embeddings,
                    self.config.audio_token_index,
                )
            except Exception as e:
                logger.error(f"merge_multimodal_embeddings failed: {e}", exc_info=True)
                raise
        
        return inputs_embeds

    def forward(
        self,
        input_ids: torch.Tensor,
        positions: torch.Tensor,
        intermediate_tensors: Optional[IntermediateTensors] = None,
        inputs_embeds: Optional[torch.Tensor] = None,
        **kwargs: object,
    ) -> Union[torch.Tensor, IntermediateTensors]:
        if _PROFILE_AUDIO:
            cache_status = []
            if intermediate_tensors is not None:
                cache_status.append("intermediate_tensors(cached)")
            if inputs_embeds is not None:
                cache_status.append("inputs_embeds(cached)")
            if cache_status:
                print(f"[PERF] forward: Using cache - {', '.join(cache_status)}, skipping get_multimodal_embeddings", flush=True)
            else:
                print(f"[PERF] forward: No cache, will call get_multimodal_embeddings", flush=True)

        if intermediate_tensors is not None:
            inputs_embeds = None
        elif inputs_embeds is None:
            try:
                multimodal_embeddings = self.get_multimodal_embeddings(**kwargs)

                inputs_embeds = self.get_input_embeddings(
                    input_ids,
                    multimodal_embeddings,
                )
                input_ids = None
            except Exception as e:
                logger.error(f"Failed to get multimodal embeddings or input embeddings: {e}", exc_info=True)
                raise

        try:
            with _TimingContext("decoder_forward"):
                hidden_states = self.language_model.model(
                    input_ids,
                    positions,
                    intermediate_tensors,
                    inputs_embeds=inputs_embeds,
                )
            return hidden_states
        except Exception as e:
            logger.error(f"language_model.model call failed: {e}", exc_info=True)
            raise

    def compute_logits(
        self,
        hidden_states: torch.Tensor,
        sampling_metadata: SamplingMetadata,
    ) -> Optional[torch.Tensor]:
        with _TimingContext("decoder_compute_logits"):
            return self.language_model.compute_logits(hidden_states, sampling_metadata)

    def load_weights(self, weights: Iterable[tuple[str, torch.Tensor]]) -> set[str]:
        loader = AutoWeightsLoader(
            self,
            skip_substrs=[
                "positional_embedding.positional_embedding",
            ]
        )
        load_weights_set = loader.load_weights(weights)
        ignored_weights_set = {
            "audio_tower.conv2.weight",
            "audio_tower.conv1.weight",
            "audio_tower.conv1.bias",
            "audio_tower.conv2.bias",
        }
        load_weights_set = load_weights_set.union(ignored_weights_set)
        return load_weights_set
