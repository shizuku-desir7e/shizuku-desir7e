import logging
import os
import time
import warnings
from collections.abc import Iterable, Mapping, Sequence
from typing import Any, Optional, TypedDict, Union

import torch
import torch.nn as nn
from transformers import BatchFeature

# Performance profiling flag - set VLLM_PROFILE_AUDIO=1 to enable
_PROFILE_AUDIO = os.getenv("VLLM_PROFILE_AUDIO", "0") == "1"
if _PROFILE_AUDIO:
    print(f"[PERF-INIT] Performance profiling enabled for Qwen3Omni", flush=True)

from transformers.models.whisper import WhisperFeatureExtractor

from llamafactory.model.qwen3_omni_speech_encoder.build_model import (
    build_qwen3_omni_text,
)
from llamafactory.model.qwen3_omni_speech_encoder.modeling_qwen3_omni_text import (
    Qwen3OmniTextConfig,
    Qwen3OmniMoeAudioEncoder,
    Qwen3AudioMultiModalProjector,
    _get_feat_extract_output_lengths,
)

build_qwen3_omni_text()

from vllm import envs
from vllm.config import VllmConfig
from vllm.model_executor.sampling_metadata import SamplingMetadata
from vllm.multimodal import MULTIMODAL_REGISTRY
from vllm.multimodal.inputs import (
    MultiModalDataDict,
    MultiModalFieldConfig,
    MultiModalKwargs,
    MultiModalKwargsItem,
)
from vllm.multimodal.parse import MultiModalDataItems, MultiModalDataParser
from vllm.multimodal.processing import (
    BaseProcessingInfo,
    BaseMultiModalProcessor,
    PromptReplacement,
    PromptUpdate,
    PromptUpdateDetails,
)
from vllm.multimodal.profiling import BaseDummyInputsBuilder
from vllm.sequence import IntermediateTensors

from .interfaces import MultiModalEmbeddings, SupportsMultiModal, SupportsPP
from .utils import (
    AutoWeightsLoader,
    init_vllm_registered_model,
    maybe_prefix,
    merge_multimodal_embeddings,
)

logger = logging.getLogger(__name__)


class _TimingContext:
    """Context manager for timing operations when profiling is enabled."""
    def __init__(self, name: str):
        self.name = name
        self.start_time = None

    def __enter__(self):
        if _PROFILE_AUDIO:
            self.start_time = time.perf_counter()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if _PROFILE_AUDIO and self.start_time is not None:
            elapsed = time.perf_counter() - self.start_time
            print(f"[PERF] {self.name}: {elapsed*1000:.2f}ms", flush=True)


class Qwen3OmniTextAudioInputs(TypedDict):
    input_features: torch.Tensor
    feature_attention_mask: torch.Tensor


class Qwen3OmniTextProcessingInfo(BaseProcessingInfo):

    def get_hf_config(self):
        return self.ctx.get_hf_config(Qwen3OmniTextConfig)

    def get_hf_processor(
        self,
        *,
        sampling_rate: Optional[int] = None,
        **kwargs: object,
    ):
        # Try to load processor from LLaMA-Factory
        processor = None
        
        # Try standard audio processor
        try:
            from llamafactory.model.qwen3_omni_speech_encoder.processor_qwen3_omni_text import (
                CustomQwen3OmniAudioProcessor,
            )
            processor = self.ctx.get_hf_processor(CustomQwen3OmniAudioProcessor, **kwargs)
            logger.debug("Successfully loaded CustomQwen3OmniAudioProcessor")
        except (ValueError, ImportError, TypeError) as e:
            logger.debug(f"CustomQwen3OmniAudioProcessor not available: {e}")
        
        # If we got a processor, ensure it has required audio token attributes
        if processor is not None:
            if not hasattr(processor, "audio_token"):
                processor.audio_token = "<|AUDIO|>"
                logger.debug("Added missing audio_token attribute to processor")
            if not hasattr(processor, "audio_bos_token"):
                processor.audio_bos_token = "<|audio_bos|>"
                logger.debug("Added missing audio_bos_token attribute to processor")
            if not hasattr(processor, "audio_eos_token"):
                processor.audio_eos_token = "<|audio_eos|>"
                logger.debug("Added missing audio_eos_token attribute to processor")
            return processor
        
        # Last resort: create a minimal processor manually
        logger.warning("Could not load LLaMA-Factory processors, creating minimal processor")
        try:
            from transformers.models.whisper import WhisperFeatureExtractor
            from transformers import AutoTokenizer
            
            model_path = self.ctx.model_config.model
            feature_extractor = WhisperFeatureExtractor.from_pretrained(
                model_path,
                trust_remote_code=self.ctx.model_config.trust_remote_code,
            )
            tokenizer = AutoTokenizer.from_pretrained(
                model_path,
                trust_remote_code=self.ctx.model_config.trust_remote_code,
            )
            
            # Create a minimal processor-like object
            class MinimalQwen3OmniProcessor:
                def __init__(self, feature_extractor, tokenizer):
                    self.feature_extractor = feature_extractor
                    self.tokenizer = tokenizer
                    # Use getattr with defaults for compatibility
                    self.audio_token = getattr(tokenizer, "audio_token", "<|AUDIO|>")
                    self.audio_bos_token = getattr(tokenizer, "audio_bos_token", "<|audio_bos|>")
                    self.audio_eos_token = getattr(tokenizer, "audio_eos_token", "<|audio_eos|>")
                
                def __call__(self, text=None, audio=None, return_tensors=None, **kwargs):
                    from transformers import BatchFeature
                    result = {}
                    
                    sampling_rate = kwargs.pop('sampling_rate', None)
                    common_kwargs = {}
                    if return_tensors is not None:
                        common_kwargs['return_tensors'] = return_tensors
                    
                    if text is not None:
                        if isinstance(text, str):
                            text = [text]
                        tokenizer_kwargs = {k: v for k, v in kwargs.items() 
                                          if k not in ['sampling_rate', 'audio']}
                        tokenizer_kwargs.update(common_kwargs)
                        tokenizer_output = self.tokenizer(text, **tokenizer_kwargs)
                        result.update(tokenizer_output)
                    
                    if audio is not None:
                        if not isinstance(audio, list):
                            audio = [audio]
                        feature_extractor_kwargs = dict(kwargs)
                        if sampling_rate is not None:
                            feature_extractor_kwargs['sampling_rate'] = sampling_rate
                        feature_extractor_kwargs.update(common_kwargs)
                        feature_extractor_output = self.feature_extractor(
                            audio, **feature_extractor_kwargs
                        )
                        result.update(feature_extractor_output)
                    
                    return BatchFeature(result, tensor_type=return_tensors)
            
            logger.debug("Created minimal Qwen3Omni processor manually")
            return MinimalQwen3OmniProcessor(feature_extractor, tokenizer)  # type: ignore
        except Exception as e:
            logger.error(f"Failed to create processor manually: {e}", exc_info=True)
            raise

    def get_feature_extractor(
        self,
        *,
        sampling_rate: Optional[int] = None,
    ) -> WhisperFeatureExtractor:
        hf_processor = self.get_hf_processor(sampling_rate=sampling_rate)
        feature_extractor = hf_processor.feature_extractor  # type: ignore
        assert isinstance(feature_extractor, WhisperFeatureExtractor)
        return feature_extractor

    def get_supported_mm_limits(self) -> Mapping[str, Optional[int]]:
        return {"audio": None}


class Qwen3OmniTextDummyInputsBuilder(
    BaseDummyInputsBuilder[Qwen3OmniTextProcessingInfo]
):

    def get_dummy_text(self, mm_counts: Mapping[str, int]) -> str:
        num_audios = mm_counts.get("audio", 0)
        processor = self.info.get_hf_processor()
        return processor.audio_token * num_audios

    def get_dummy_mm_data(
        self,
        seq_len: int,
        mm_counts: Mapping[str, int],
    ) -> MultiModalDataDict:
        feature_extractor = self.info.get_feature_extractor()
        # Minimize dummy audio length for profiling
        audio_len = min(
            feature_extractor.chunk_length * feature_extractor.sampling_rate,
            feature_extractor.sampling_rate  # 1 second max
        )
        num_audios = mm_counts.get("audio", 0)
        return {"audio": self._get_dummy_audios(length=audio_len, num_audios=num_audios)}


class Qwen3OmniTextMultiModalProcessor(
    BaseMultiModalProcessor[Qwen3OmniTextProcessingInfo]
):

    def _get_data_parser(self) -> MultiModalDataParser:
        feature_extractor = self.info.get_feature_extractor()
        return MultiModalDataParser(target_sr=feature_extractor.sampling_rate)

    def _call_hf_processor(
        self,
        prompt: str,
        mm_data: Mapping[str, object],
        mm_kwargs: Mapping[str, Any],
        tok_kwargs: Mapping[str, object],
    ) -> BatchFeature:
        logger.debug(f"[TRACE] _call_hf_processor ENTRY, prompt len: {len(prompt)}, mm_data keys: {list(mm_data.keys())}")
        try:
            data = dict(mm_data)
            audios = data.pop("audios", [])
            if audios:
                data["audio"] = audios
                logger.debug(f"[TRACE] Found {len(audios)} audio(s)")

            if not data.get("audio", []):
                logger.debug("[TRACE] No audio data, returning text-only result")
                prompt_ids = self.info.get_tokenizer().encode(prompt)
                prompt_ids = self._apply_hf_processor_tokens_only(prompt_ids)
                return BatchFeature(dict(input_ids=[prompt_ids]), tensor_type="pt")

            logger.debug("[TRACE] Getting feature_extractor")
            feature_extractor = self.info.get_feature_extractor(**mm_kwargs)
            mm_kwargs = dict(**mm_kwargs, sampling_rate=feature_extractor.sampling_rate)
            logger.debug(f"[TRACE] Calling super()._call_hf_processor with sampling_rate={feature_extractor.sampling_rate}")
            result = super()._call_hf_processor(
                prompt=prompt,
                mm_data=data,
                mm_kwargs=mm_kwargs,
                tok_kwargs=tok_kwargs,
            )
            logger.debug(f"[TRACE] super()._call_hf_processor returned, result keys: {list(result.keys())}")
            
            # Debug: Check if input_ids contain audio token
            if "input_ids" in result:
                input_ids = result["input_ids"]
                logger.debug(f"[TRACE] input_ids type: {type(input_ids)}, len/shape: {len(input_ids) if isinstance(input_ids, list) else input_ids.shape}")
                # Check for audio token (151665)
                if isinstance(input_ids, torch.Tensor):
                    audio_token_count = (input_ids == 151665).sum().item()
                    logger.debug(f"[TRACE] Audio token (151665) count in input_ids: {audio_token_count}")
                    if audio_token_count == 0:
                        logger.warning("[TRACE] WARNING: No audio token found in input_ids! Checking first 20 tokens...")
                        logger.debug(f"[TRACE] First 20 input_ids: {input_ids.flatten()[:20].tolist()}")
                elif isinstance(input_ids, list) and len(input_ids) > 0:
                    if isinstance(input_ids[0], list):
                        flat_ids = input_ids[0]
                    else:
                        flat_ids = input_ids
                    audio_token_count = sum(1 for t in flat_ids if t == 151665)
                    logger.debug(f"[TRACE] Audio token (151665) count in input_ids: {audio_token_count}")
                    if audio_token_count == 0:
                        logger.warning("[TRACE] WARNING: No audio token found in input_ids!")
                        logger.debug(f"[TRACE] First 20 input_ids: {flat_ids[:20]}")
            
            # Ensure feature_attention_mask exists
            if "input_features" in result:
                logger.debug("[TRACE] input_features found in result")
                input_features = result["input_features"]
                if "feature_attention_mask" not in result:
                    attention_mask = result.get("attention_mask")
                    feature_attention_mask: torch.Tensor
                    try:
                        seq_len = input_features.shape[-1] if hasattr(input_features, "shape") else None
                        if attention_mask is not None:
                            feature_attention_mask = attention_mask.to(dtype=torch.long)
                            if feature_attention_mask.dim() == 3:
                                feature_attention_mask = feature_attention_mask.squeeze(1)
                            if feature_attention_mask.dim() == 1:
                                feature_attention_mask = feature_attention_mask.unsqueeze(-1)
                            if seq_len is not None and feature_attention_mask.shape[-1] != seq_len:
                                mask_len = feature_attention_mask.shape[-1]
                                if mask_len > seq_len:
                                    feature_attention_mask = feature_attention_mask[..., :seq_len]
                                else:
                                    pad_amount = seq_len - mask_len
                                    feature_attention_mask = torch.nn.functional.pad(
                                        feature_attention_mask, (0, pad_amount), value=0
                                    )
                        else:
                            batch_size = input_features.shape[0]
                            seq_len = input_features.shape[-1]
                            device = input_features.device if hasattr(input_features, "device") else None
                            dtype = torch.long
                            feature_attention_mask = torch.ones(
                                batch_size,
                                seq_len,
                                dtype=dtype,
                                device=device,
                            )
                    except Exception as mask_err:
                        logger.error(f"Failed to generate feature_attention_mask: {mask_err}", exc_info=True)
                        raise

                    result["feature_attention_mask"] = feature_attention_mask
            return result
        except Exception as e:
            logger.error(f"Call failed: {e}", exc_info=True)
            raise

    def _hf_processor_applies_updates(
        self,
        prompt_text: str,
        mm_items: MultiModalDataItems,
        hf_processor_mm_kwargs: Mapping[str, object],
        tokenization_kwargs: Mapping[str, object],
    ) -> bool:
        # CustomQwen3OmniAudioProcessor expands audio tokens during processing
        # So we need to return True when there are audio items
        has_audio = "audio" in mm_items and len(mm_items["audio"]) > 0
        logger.debug(f"[TRACE] _hf_processor_applies_updates called, has_audio={has_audio}, returning {has_audio}")
        return has_audio

    def _get_mm_fields_config(
        self,
        hf_inputs: BatchFeature,
        hf_processor_mm_kwargs: Mapping[str, object],
    ) -> Mapping[str, MultiModalFieldConfig]:
        logger.debug(f"[TRACE] _get_mm_fields_config ENTRY, hf_inputs keys: {list(hf_inputs.keys()) if hf_inputs else 'None'}")
        try:
            result = dict(
                input_features=MultiModalFieldConfig.batched("audio"),
                feature_attention_mask=MultiModalFieldConfig.batched("audio"),
            )
            logger.debug(f"[TRACE] _get_mm_fields_config returning: {list(result.keys())}")
            return result
        except Exception as e:
            logger.error(f"[ERROR] Failed to get config: {e}", exc_info=True)
            raise

    def _get_prompt_updates(
        self,
        mm_items: MultiModalDataItems,
        hf_processor_mm_kwargs: Mapping[str, object],
        out_mm_kwargs: MultiModalKwargs,
    ) -> Sequence[PromptUpdate]:
        logger.debug("="*80)
        logger.debug(f"[TRACE] _get_prompt_updates ENTRY, out_mm_kwargs keys: {list(out_mm_kwargs.keys())}")
        logger.debug("="*80)
        try:
            processor = self.info.get_hf_processor(**hf_processor_mm_kwargs)
            tokenizer = self.info.get_tokenizer()
            vocab = tokenizer.get_vocab()

            audio_token = getattr(processor, "audio_token", "<|AUDIO|>")
            audio_bos_token = getattr(processor, "audio_bos_token", "<|audio_bos|>")
            audio_eos_token = getattr(processor, "audio_eos_token", "<|audio_eos|>")
            logger.debug(f"[TRACE] audio tokens: {audio_token}, {audio_bos_token}, {audio_eos_token}")

            audio_token_id = vocab[audio_token]
            audio_bos_id = vocab[audio_bos_token]
            audio_eos_id = vocab[audio_eos_token]
            logger.debug(f"[TRACE] audio token ids: {audio_token_id}, {audio_bos_id}, {audio_eos_id}")

            feature_attention_mask = out_mm_kwargs.get("feature_attention_mask")
            logger.debug(f"[TRACE] feature_attention_mask from out_mm_kwargs: {feature_attention_mask is not None}")
            
            if feature_attention_mask is None and "audio" in out_mm_kwargs:
                logger.debug("[TRACE] Attempting to extract feature_attention_mask from audio items")
                try:
                    audio_items = out_mm_kwargs["audio"]
                    logger.debug(f"[TRACE] audio_items type: {type(audio_items)}, len: {len(audio_items) if hasattr(audio_items, '__len__') else 'N/A'}")
                    fam_list = []
                    for idx, item in enumerate(audio_items):
                        logger.debug(f"[TRACE] Processing audio item {idx}, type: {type(item)}")
                        if isinstance(item, MultiModalKwargsItem):
                            data_dict = item.get_data()
                            logger.debug(f"[TRACE] data_dict keys: {list(data_dict.keys())}")
                            fam_tensor = data_dict.get("feature_attention_mask")
                            if fam_tensor is None:
                                logger.debug(f"[TRACE] feature_attention_mask is None for item {idx}")
                                continue
                            logger.debug(f"[TRACE] Found feature_attention_mask for item {idx}, shape: {fam_tensor.shape}")
                            fam_tensor = fam_tensor if fam_tensor.dim() == 1 else fam_tensor.view(-1)
                            fam_list.append(fam_tensor)
                    logger.debug(f"[TRACE] Collected {len(fam_list)} feature_attention_mask(s)")
                    if len(fam_list) > 0:
                        feature_attention_mask = torch.stack(fam_list, dim=0)
                        logger.debug(f"[TRACE] Stacked feature_attention_mask shape: {feature_attention_mask.shape}")
                except Exception as err:
                    logger.error(f"[ERROR] normalize nested feature_attention_mask failed: {err}", exc_info=True)

            if feature_attention_mask is None:
                logger.debug("[TRACE] feature_attention_mask is None, audio_output_lengths will be empty")
                audio_output_lengths: list[int] = []
            else:
                assert isinstance(feature_attention_mask, torch.Tensor)
                feature_lens_sum = feature_attention_mask.sum(-1)
                logger.debug(f"[TRACE] feature_lens_sum: {feature_lens_sum}")
                audio_output_lens = _get_feat_extract_output_lengths(feature_lens_sum)
                audio_output_lengths = audio_output_lens.tolist()
                logger.debug(f"[TRACE] audio_output_lengths: {audio_output_lengths}")

            def get_replacement_qwen3_audio(item_idx: int):
                logger.debug(f"[TRACE] get_replacement_qwen3_audio called with item_idx: {item_idx}")
                try:
                    if audio_output_lengths:
                        safe_idx = min(item_idx, len(audio_output_lengths) - 1)
                        if item_idx >= len(audio_output_lengths):
                            warnings.warn(
                                "Requested audio item index %s exceeds available lengths %s. "
                                "Falling back to last valid index %s." % (item_idx, len(audio_output_lengths), safe_idx)
                            )
                            logger.warning(f"[TRACE] item_idx {item_idx} >= len {len(audio_output_lengths)}, using safe_idx {safe_idx}")
                        num_features = audio_output_lengths[safe_idx]
                        logger.debug(f"[TRACE] num_features from audio_output_lengths[{safe_idx}]: {num_features}")
                    else:
                        num_features = 1
                        logger.debug("[TRACE] audio_output_lengths is empty, using default num_features=1")

                    if num_features == 0:
                        audios = mm_items.get_items("audio")
                        error_msg = f"The audio (len={audios.get_audio_length(item_idx)}) is too short to be represented inside the model"  # type: ignore[attr-defined]
                        logger.error(f"[ERROR] {error_msg}")
                        raise ValueError(error_msg)

                    audio_tokens = [audio_token_id] * num_features
                    logger.debug(f"[TRACE] Creating replacement with {num_features} audio tokens")
                    logger.debug(f"[TRACE] Token: audio_token={audio_token_id}")
                    # Note: Do NOT add bos/eos here because chat_template already includes them
                    # chat_template generates: <|audio_bos|><|AUDIO|><|audio_eos|>
                    # We only replace the <|AUDIO|> token with num_features audio tokens
                    token_list = audio_tokens
                    logger.debug(f"[TRACE] Full token list length: {len(token_list)}")
                    
                    result = PromptUpdateDetails.select_token_id(
                        token_list,
                        embed_token_id=audio_token_id,
                    )
                    logger.debug(f"[TRACE] PromptUpdateDetails.select_token_id returned: {type(result)}")
                    return result
                except Exception as e:
                    logger.error(f"[ERROR] get_replacement_qwen3_audio failed: {e}", exc_info=True)
                    raise

            result = [
                PromptReplacement(
                    modality="audio",
                    target=audio_token,
                    replacement=get_replacement_qwen3_audio,
                )
            ]
            logger.debug(f"[TRACE] _get_prompt_updates returning {len(result)} PromptReplacement(s)")
            return result
        except Exception as e:
            logger.error(f"[ERROR] Failed to get prompt updates: {e}", exc_info=True)
            raise


@MULTIMODAL_REGISTRY.register_processor(
    Qwen3OmniTextMultiModalProcessor,
    info=Qwen3OmniTextProcessingInfo,
    dummy_inputs=Qwen3OmniTextDummyInputsBuilder,
)
class Qwen3OmniTextForConditionalGeneration(nn.Module, SupportsMultiModal, SupportsPP):

    @classmethod
    def get_placeholder_str(cls, modality: str, i: int) -> Optional[str]:
        if modality.startswith("audio"):
            return f"Audio {i}: <|audio_bos|><|AUDIO|><|audio_eos|>"
        raise ValueError("Only audio modality is supported")

    def __init__(self, *, vllm_config: VllmConfig, prefix: str = ""):
        logger.debug("="*80)
        logger.debug("[Qwen3OmniTextForConditionalGeneration.__init__] Starting initialization")
        logger.debug("="*80)
        
        super().__init__()
        logger.debug("[Qwen3OmniTextForConditionalGeneration.__init__] super().__init__() completed")
        
        try:
            logger.debug("[Qwen3OmniTextForConditionalGeneration.__init__] Getting config from vllm_config")
            config = vllm_config.model_config.hf_config
            logger.debug(f"[Qwen3OmniTextForConditionalGeneration.__init__] Config type: {type(config)}, model_type: {getattr(config, 'model_type', 'unknown')}")
            
            quant_config = vllm_config.quant_config
            self.config = config
            self.multimodal_config = vllm_config.model_config.multimodal_config
            logger.debug("[Qwen3OmniTextForConditionalGeneration.__init__] Config assigned to self")

            # Ensure sub-configs are fully initialized
            logger.debug("[Qwen3OmniTextForConditionalGeneration.__init__] Accessing audio_config")
            audio_config = config.audio_config
            logger.debug(f"[Qwen3OmniTextForConditionalGeneration.__init__] audio_config type: {type(audio_config)}")
            
            logger.debug("[Qwen3OmniTextForConditionalGeneration.__init__] Accessing text_config")
            text_config = config.text_config
            logger.debug(f"[Qwen3OmniTextForConditionalGeneration.__init__] text_config type: {type(text_config)}")
            
            # Force initialization
            logger.debug("[Qwen3OmniTextForConditionalGeneration.__init__] Forcing initialization of audio_config")
            if hasattr(audio_config, '__dict__'):
                _ = audio_config.__dict__
                logger.debug(f"[Qwen3OmniTextForConditionalGeneration.__init__] audio_config.__dict__ accessed")
            
            logger.debug("[Qwen3OmniTextForConditionalGeneration.__init__] Forcing initialization of text_config")
            if hasattr(text_config, '__dict__'):
                _ = text_config.__dict__
                logger.debug(f"[Qwen3OmniTextForConditionalGeneration.__init__] text_config.__dict__ accessed")
            
        except Exception as e:
            logger.error(f"[Qwen3OmniTextForConditionalGeneration.__init__] Error before audio_tower initialization: {e}", exc_info=True)
            raise
        
        # Initialize audio tower with MoE audio_config
        try:
            logger.debug("[Qwen3OmniTextForConditionalGeneration.__init__] Initializing audio_tower")
            # Enable flash_attention_2 for audio_config
            try:
                import flash_attn  # type: ignore
                audio_config._attn_implementation_autoset = True
                audio_config._attn_implementation = "flash_attention_2"
                logger.debug("[Qwen3OmniTextForConditionalGeneration.__init__] Enabled flash_attention_2 for audio_tower")
            except (ImportError, AttributeError):
                logger.warning("[Qwen3OmniTextForConditionalGeneration.__init__] flash_attn not available, using default attention")

            self.audio_tower = Qwen3OmniMoeAudioEncoder(audio_config)
            logger.debug("[Qwen3OmniTextForConditionalGeneration.__init__] audio_tower initialized successfully")
        except Exception as e:
            logger.error(f"[Qwen3OmniTextForConditionalGeneration.__init__] Error initializing audio_tower: {e}", exc_info=True)
            raise
            
        self.audio_tower.to(self.audio_tower.conv2d1.weight.device)
        
        # Move positional_embedding and layers to correct device
        if hasattr(self.audio_tower, "positional_embedding"):
            self.audio_tower.positional_embedding.to(
                dtype=self.audio_tower.conv2d1.weight.dtype,
                device=self.audio_tower.conv2d1.weight.device
            )
        if hasattr(self.audio_tower, "layers"):
            for layer in self.audio_tower.layers:
                layer.to(
                    dtype=self.audio_tower.conv2d1.weight.dtype,
                    device=self.audio_tower.conv2d1.weight.device
                )

        try:
            logger.debug("[Qwen3OmniTextForConditionalGeneration.__init__] Initializing multi_modal_projector")
            self.multi_modal_projector = Qwen3AudioMultiModalProjector(config)
            logger.debug("[Qwen3OmniTextForConditionalGeneration.__init__] multi_modal_projector initialized")

            self.quant_config = quant_config
            logger.debug("[Qwen3OmniTextForConditionalGeneration.__init__] Initializing language_model")
            self.language_model = init_vllm_registered_model(
                vllm_config=vllm_config,
                hf_config=config.text_config,
                prefix=maybe_prefix(prefix, "language_model"),
                architectures=["Qwen2ForCausalLM"],
            )
            logger.debug("[Qwen3OmniTextForConditionalGeneration.__init__] language_model initialized")

            self.make_empty_intermediate_tensors = (
                self.language_model.make_empty_intermediate_tensors
            )

            self.pad_token_id = self.config.pad_token_id if self.config.pad_token_id is not None else -1
            self._padding_side = "left"
            logger.debug("[Qwen3OmniTextForConditionalGeneration.__init__] Initialization completed successfully")
        except Exception as e:
            logger.error(f"[Qwen3OmniTextForConditionalGeneration.__init__] Error during final initialization: {e}", exc_info=True)
            raise

    def _validate_and_reshape_mm_tensor(
        self,
        mm_input: object,
        name: str,
    ) -> torch.Tensor:
        if not isinstance(mm_input, (torch.Tensor, list)):
            raise ValueError(f"Incorrect type of {name}. Got type: {type(mm_input)}")
        if isinstance(mm_input, torch.Tensor):
            return torch.concat(list(mm_input))
        return torch.concat(mm_input)

    def _parse_and_validate_audio_input(
        self,
        **kwargs: object,
    ) -> Optional[Qwen3OmniTextAudioInputs]:
        logger.debug(f"[TRACE] _parse_and_validate_audio_input called with kwargs keys: {list(kwargs.keys())}")
        input_features = kwargs.pop("input_features", None)
        feature_attention_mask = kwargs.pop("feature_attention_mask", None)
        
        logger.debug(f"[TRACE] input_features type: {type(input_features)}, is None: {input_features is None}")
        logger.debug(f"[TRACE] feature_attention_mask type: {type(feature_attention_mask)}, is None: {feature_attention_mask is None}")

        if input_features is None:
            logger.debug("[TRACE] input_features is None, returning None")
            return None

        try:
            logger.debug(f"[TRACE] Before validate input_features shape/type: {type(input_features)}")
            input_features = self._validate_and_reshape_mm_tensor(input_features, "input_features")
            logger.debug(f"[TRACE] After validate input_features shape: {input_features.shape if hasattr(input_features, 'shape') else 'no shape'}")
        except Exception as e:
            logger.error(f"[ERROR] Failed to validate input_features: {e}", exc_info=True)
            raise

        # Handle None feature_attention_mask
        if feature_attention_mask is None:
            logger.debug("[TRACE] feature_attention_mask is None, creating default mask")
            if isinstance(input_features, torch.Tensor):
                if input_features.dim() == 3:
                    batch_size, num_mel_bins, max_seq_len = input_features.shape
                    logger.debug(f"[TRACE] input_features shape: batch_size={batch_size}, num_mel_bins={num_mel_bins}, max_seq_len={max_seq_len}")
                    max_reasonable_seq_len = min(max_seq_len, 500)
                    feature_attention_mask = torch.ones(
                        batch_size, max_reasonable_seq_len,
                        dtype=torch.long,
                        device=input_features.device
                    )
                    if max_seq_len > max_reasonable_seq_len:
                        input_features = input_features[:, :, :max_reasonable_seq_len]
                        logger.debug(f"[TRACE] Truncated input_features to {max_reasonable_seq_len}")
                else:
                    logger.debug(f"[TRACE] input_features has unexpected dim: {input_features.dim()}")
                    feature_attention_mask = torch.ones(
                        input_features.shape[0] if input_features.dim() > 0 else 1,
                        min(input_features.shape[-1] if input_features.dim() > 1 else input_features.shape[0], 500),
                        dtype=torch.long,
                        device=input_features.device
                    )
            else:
                logger.error("[ERROR] feature_attention_mask is None and input_features is not a Tensor")
                raise ValueError(
                    "feature_attention_mask is None and input_features is a list. "
                    "Please provide feature_attention_mask explicitly."
                )
            logger.debug(f"[TRACE] Created feature_attention_mask with shape: {feature_attention_mask.shape}")
        else:
            try:
                logger.debug(f"[TRACE] Validating existing feature_attention_mask")
                feature_attention_mask = self._validate_and_reshape_mm_tensor(
                    feature_attention_mask, "feature_attention_mask"
                )
                logger.debug(f"[TRACE] Validated feature_attention_mask shape: {feature_attention_mask.shape}")
            except Exception as e:
                logger.error(f"[ERROR] Failed to validate feature_attention_mask: {e}", exc_info=True)
                raise

        if not isinstance(input_features, (torch.Tensor, list)):
            error_msg = f"Incorrect type of audio input features. Got type: {type(input_features)}"
            raise ValueError(error_msg)

        return Qwen3OmniTextAudioInputs(
            input_features=input_features,
            feature_attention_mask=feature_attention_mask,
        )

    def _process_audio_input(self, audio_input: Qwen3OmniTextAudioInputs):
        logger.debug("[TRACE] _process_audio_input called")
        if envs.VLLM_USE_V1:
            logger.debug("[TRACE] Using V1 path")
            return self._process_audio_input_v1(audio_input)

        with _TimingContext("_process_audio_input"):
            input_features_ = audio_input["input_features"]
            feature_attention_mask = audio_input["feature_attention_mask"]
            logger.debug(f"[TRACE] input_features_ shape: {input_features_.shape}, dtype: {input_features_.dtype}")
            logger.debug(f"[TRACE] feature_attention_mask shape: {feature_attention_mask.shape}, dtype: {feature_attention_mask.dtype}")

            with _TimingContext("calculate_feature_lengths"):
                feature_lens = feature_attention_mask.sum(-1)
                logger.debug(f"[TRACE] feature_lens: {feature_lens}")
                # Qwen3 _get_feat_extract_output_lengths returns only one value
                audio_output_lengths = _get_feat_extract_output_lengths(feature_lens)
                logger.debug(f"[TRACE] audio_output_lengths: {audio_output_lengths}")

            batch_size, num_mel_bins, max_seq_len = input_features_.shape
            logger.debug(f"[TRACE] batch_size={batch_size}, num_mel_bins={num_mel_bins}, max_seq_len={max_seq_len}")

            with _TimingContext("prepare_input_features"):
                # Use cumsum for efficient concatenation
                feature_lens_cumsum = torch.cumsum(feature_lens, dim=0)
                total_len = feature_lens_cumsum[-1].item()
                logger.debug(f"[TRACE] total_len after cumsum: {total_len}")

                target_dtype = self.audio_tower.conv2d1.weight.dtype
                target_device = self.audio_tower.conv2d1.weight.device
                logger.debug(f"[TRACE] target_dtype: {target_dtype}, target_device: {target_device}")
                input_features = torch.zeros(
                    num_mel_bins, total_len,
                    dtype=target_dtype,
                    device=target_device
                )
                logger.debug(f"[TRACE] Allocated input_features with shape: {input_features.shape}")

                start_idx = 0
                for i in range(batch_size):
                    end_idx = start_idx + feature_lens[i].item()
                    input_features[:, start_idx:end_idx] = input_features_[i, :, :feature_lens[i].item()].to(
                        dtype=target_dtype, device=target_device
                    )
                    start_idx = end_idx
                logger.debug(f"[TRACE] Copied all features to input_features")

                feature_lens_tensor = feature_lens.to(torch.long)
                logger.debug(f"[TRACE] feature_lens_tensor: {feature_lens_tensor}")

            with _TimingContext("audio_tower_forward"):
                logger.debug(f"[TRACE] Calling audio_tower.forward with input_features shape: {input_features.shape}")
                try:
                    with torch.no_grad():
                        audio_outputs = self.audio_tower(
                            input_features,
                            feature_lens=feature_lens_tensor,
                        )
                    logger.debug(f"[TRACE] audio_tower.forward completed successfully")
                    logger.debug(f"[TRACE] audio_outputs.last_hidden_state shape: {audio_outputs.last_hidden_state.shape}")
                except Exception as e:
                    logger.error(f"[ERROR] audio_tower.forward failed: {e}", exc_info=True)
                    raise

            with _TimingContext("project_and_reshape"):
                audio_hidden_states = audio_outputs.last_hidden_state
                logger.debug(f"[TRACE] Calling multi_modal_projector with shape: {audio_hidden_states.shape}")
                try:
                    audio_features = self.multi_modal_projector(audio_hidden_states)
                    logger.debug(f"[TRACE] multi_modal_projector output shape: {audio_features.shape}")
                except Exception as e:
                    logger.error(f"[ERROR] multi_modal_projector failed: {e}", exc_info=True)
                    raise

                # Reshape to (batch_size, max_audio_tokens, embed_dim)
                audio_output_lengths_list = audio_output_lengths.tolist()
                logger.debug(f"[TRACE] audio_output_lengths_list: {audio_output_lengths_list}")
                audio_features_list = audio_features.split(audio_output_lengths_list, dim=0)
                max_audio_tokens = max(len(f) for f in audio_features_list) if audio_features_list else 0
                embed_dim = audio_features.shape[-1]
                logger.debug(f"[TRACE] max_audio_tokens: {max_audio_tokens}, embed_dim: {embed_dim}")

                if max_audio_tokens > 0:
                    from torch.nn.utils.rnn import pad_sequence
                    audio_features_batched = pad_sequence(
                        audio_features_list,
                        batch_first=True,
                        padding_value=0.0
                    )
                    logger.debug(f"[TRACE] audio_features_batched shape: {audio_features_batched.shape}")
                else:
                    audio_features_batched = torch.empty(0, 0, embed_dim, device=audio_features.device, dtype=audio_features.dtype)
                    logger.debug(f"[TRACE] Created empty audio_features_batched")

            logger.debug(f"[TRACE] _process_audio_input returning: features shape {audio_features_batched.shape}, lengths {audio_output_lengths}")
            return audio_features_batched, audio_output_lengths

    def _process_audio_input_v1(self, audio_input: Qwen3OmniTextAudioInputs):
        with _TimingContext("_process_audio_input_v1"):
            input_features_ = audio_input["input_features"]
            feature_attention_mask = audio_input["feature_attention_mask"]
            logger.debug(f"[TRACE V1] _process_audio_input_v1: input_features_ shape={input_features_.shape}")
            logger.debug(f"[TRACE V1] _process_audio_input_v1: feature_attention_mask shape={feature_attention_mask.shape}")

            with _TimingContext("calculate_feature_lengths_v1"):
                feature_lens = feature_attention_mask.sum(-1)
                logger.debug(f"[TRACE V1] _process_audio_input_v1: feature_lens={feature_lens}")
                
                # 分析音频数据质量
                if input_features_.shape[0] > 0 and feature_lens[0] > 0:
                    valid_len = min(int(feature_lens[0].item()), input_features_.shape[2])
                    # 计算非零值的比例
                    valid_features = input_features_[:, :, :valid_len]
                    non_zero_ratio = (valid_features != 0).float().mean().item()
                    # 计算音频能量（RMS）
                    audio_energy = torch.sqrt((valid_features ** 2).mean()).item()
                    # 计算最大最小值
                    audio_max = valid_features.max().item()
                    audio_min = valid_features.min().item()
                    logger.debug(f"[AUDIO_QUALITY] valid_frames={valid_len}, total_frames={input_features_.shape[2]}, valid_ratio={valid_len/input_features_.shape[2]:.4f}")
                    logger.debug(f"[AUDIO_QUALITY] non_zero_ratio={non_zero_ratio:.4f}, energy={audio_energy:.6f}, min={audio_min:.4f}, max={audio_max:.4f}")
                
                # Qwen3 _get_feat_extract_output_lengths returns only one value
                audio_output_lengths = _get_feat_extract_output_lengths(feature_lens)
                audio_output_expected_lengths = _get_feat_extract_output_lengths(feature_lens)
                logger.debug(f"[TRACE V1] _process_audio_input_v1: audio_output_lengths={audio_output_lengths}")

            batch_size, num_mel_bins, max_seq_len = input_features_.shape

            with _TimingContext("prepare_input_features_v1"):
                feature_lens_cumsum = torch.cumsum(feature_lens, dim=0)
                total_len = feature_lens_cumsum[-1].item()

                target_dtype = self.audio_tower.conv2d1.weight.dtype
                target_device = self.audio_tower.conv2d1.weight.device
                input_features = torch.zeros(
                    num_mel_bins, total_len,
                    dtype=target_dtype,
                    device=target_device
                )

                start_idx = 0
                for i in range(batch_size):
                    end_idx = start_idx + feature_lens[i].item()
                    input_features[:, start_idx:end_idx] = input_features_[i, :, :feature_lens[i].item()].to(
                        dtype=target_dtype, device=target_device
                    )
                    start_idx = end_idx

                feature_lens_tensor = feature_lens.to(torch.long)

            with _TimingContext("audio_tower_forward_v1"):
                with torch.no_grad():
                    audio_outputs = self.audio_tower(
                        input_features,
                        feature_lens=feature_lens_tensor,
                    )

            with _TimingContext("project_and_reshape_v1"):
                audio_hidden_states = audio_outputs.last_hidden_state
                logger.debug(f"[AUDIO_ENCODER] hidden_states shape={audio_hidden_states.shape}, mean={audio_hidden_states.mean().item():.6f}, std={audio_hidden_states.std().item():.6f}")
                audio_features = self.multi_modal_projector(audio_hidden_states)
                logger.debug(f"[AUDIO_PROJECTOR] features shape={audio_features.shape}, mean={audio_features.mean().item():.6f}, std={audio_features.std().item():.6f}")

                audio_output_lengths_list = audio_output_lengths.tolist()
                audio_features_list = audio_features.split(audio_output_lengths_list, dim=0)
                max_audio_tokens = max(len(f) for f in audio_features_list) if audio_features_list else 0
                embed_dim = audio_features.shape[-1]

                if max_audio_tokens > 0:
                    from torch.nn.utils.rnn import pad_sequence
                    audio_features_batched = pad_sequence(
                        audio_features_list,
                        batch_first=True,
                        padding_value=0.0
                    )
                else:
                    audio_features_batched = torch.empty(0, 0, embed_dim, device=audio_features.device, dtype=audio_features.dtype)

            return audio_features_batched, audio_output_lengths, audio_output_expected_lengths

    def get_language_model(self) -> torch.nn.Module:
        return self.language_model

    def get_multimodal_embeddings(
        self,
        **kwargs: object,
    ) -> MultiModalEmbeddings:
        logger.debug(f"[TRACE] ===== get_multimodal_embeddings ENTRY ===== kwargs keys: {list(kwargs.keys())}")
        if _PROFILE_AUDIO:
            print(f"[PERF] get_multimodal_embeddings called, kwargs keys: {list(kwargs.keys())}", flush=True)
        with _TimingContext("get_multimodal_embeddings"):
            if envs.VLLM_USE_V1:
                logger.debug("[TRACE] Using VLLM_USE_V1 path")
                return self.get_multimodal_embeddings_v1(**kwargs)

            try:
                logger.debug("[TRACE] Calling _parse_and_validate_audio_input")
                with _TimingContext("parse_audio_input"):
                    audio_input = self._parse_and_validate_audio_input(**kwargs)
                logger.debug(f"[TRACE] _parse_and_validate_audio_input returned: {audio_input is not None}")
                if audio_input is None:
                    if _PROFILE_AUDIO:
                        print(f"[PERF] get_multimodal_embeddings: audio_input is None, returning []", flush=True)
                    logger.debug("[TRACE] audio_input is None, returning empty list")
                    return []
                logger.debug("[TRACE] Calling _process_audio_input")
                result = self._process_audio_input(audio_input)
                logger.debug(f"[TRACE] _process_audio_input returned result type: {type(result)}")
                return result
            except Exception as e:
                logger.error(f"[ERROR] get_multimodal_embeddings failed: {e}", exc_info=True)
                raise

    def get_multimodal_embeddings_v1(
        self,
        **kwargs: object,
    ) -> MultiModalEmbeddings:
        try:
            audio_input = self._parse_and_validate_audio_input(**kwargs)
            if audio_input is None:
                return []

            (
                audio_features,
                audio_output_lengths,
                audio_output_expected_lengths,
            ) = self._process_audio_input_v1(audio_input)
        except Exception as e:
            logger.error(f"Failed to process audio input: {e}", exc_info=True)
            raise

        try:
            num_audios, _, embed_dim = audio_features.shape
            multimodal_embeddings: list[torch.Tensor] = []
            for i in range(num_audios):
                actual_length = audio_output_lengths[i].item()
                expected_length = audio_output_expected_lengths[i].item()
                audio_embedding = audio_features[i, :actual_length, :]
                if actual_length < expected_length:
                    padding_length = expected_length - actual_length
                    padding = torch.zeros(
                        padding_length,
                        embed_dim,
                        device=audio_embedding.device,
                        dtype=audio_embedding.dtype,
                    )
                    audio_embedding = torch.cat([audio_embedding, padding], dim=0)
                elif actual_length > expected_length:
                    audio_embedding = audio_embedding[:expected_length]
                multimodal_embeddings.append(audio_embedding)

            return multimodal_embeddings
        except Exception as e:
            logger.error(f"Failed to build embedding list: {e}", exc_info=True)
            raise

    def get_input_embeddings(
        self,
        input_ids: torch.Tensor,
        multimodal_embeddings: Optional[MultiModalEmbeddings] = None,
    ) -> torch.Tensor:
        logger.debug(f"[TRACE] ===== get_input_embeddings ENTRY ===== input_ids shape: {input_ids.shape}")
        logger.debug(f"[TRACE] multimodal_embeddings type: {type(multimodal_embeddings)}, is None: {multimodal_embeddings is None}")
        if envs.VLLM_USE_V1:
            logger.debug("[TRACE] Using V1 path in get_input_embeddings")
            return self.get_input_embeddings_v1(input_ids, multimodal_embeddings)

        with _TimingContext("get_input_embeddings"):
            try:
                with _TimingContext("get_lm_embeddings"):
                    logger.debug("[TRACE] Getting language model input embeddings")
                    inputs_embeds = self.language_model.get_input_embeddings(input_ids)
                    logger.debug(f"[TRACE] inputs_embeds shape: {inputs_embeds.shape}")
            except Exception as e:
                logger.error(f"[ERROR] Failed to get language model input embeddings: {e}", exc_info=True)
                raise

            if multimodal_embeddings is None or len(multimodal_embeddings) == 0:
                logger.debug("[TRACE] No multimodal embeddings, returning text embeddings only")
                return inputs_embeds

            try:
                logger.debug(f"[TRACE] Unpacking multimodal_embeddings, type: {type(multimodal_embeddings)}")
                audio_features, audio_output_lengths = multimodal_embeddings
                num_audios, max_audio_tokens, embed_dim = audio_features.shape
                logger.debug(f"[TRACE] audio_features shape: ({num_audios}, {max_audio_tokens}, {embed_dim})")
                logger.debug(f"[TRACE] audio_output_lengths: {audio_output_lengths}")
            except Exception as e:
                logger.error(f"[ERROR] Failed to unpack multimodal_embeddings: {e}", exc_info=True)
                raise

            with _TimingContext("apply_audio_mask"):
                try:
                    logger.debug("[TRACE] Creating audio features mask")
                    audio_features_mask = torch.arange(max_audio_tokens, device=audio_output_lengths.device)[
                        None, :
                    ]
                    audio_features_mask = audio_features_mask < audio_output_lengths[:, None]
                    logger.debug(f"[TRACE] audio_features_mask shape: {audio_features_mask.shape}, sum: {audio_features_mask.sum().item()}")
                    audio_features = audio_features[audio_features_mask]
                    logger.debug(f"[TRACE] After masking, audio_features shape: {audio_features.shape}")
                except Exception as e:
                    logger.error(f"[ERROR] Failed to apply mask: {e}", exc_info=True)
                    raise

            try:
                n_audio_tokens = (input_ids == self.config.audio_token_index).sum().item()
                n_audio_features = audio_features.shape[0]
                logger.debug(f"[TRACE] n_audio_tokens in input_ids: {n_audio_tokens}, n_audio_features: {n_audio_features}")
            except Exception as e:
                logger.error(f"[ERROR] Failed to calculate audio token count: {e}", exc_info=True)
                raise

            with _TimingContext("adjust_audio_features"):
                try:
                    if n_audio_tokens != n_audio_features:
                        logger.debug(f"[TRACE] Adjusting audio features: need {n_audio_tokens}, have {n_audio_features}")
                        if n_audio_tokens > n_audio_features:
                            last_row = audio_features[-1:, :]
                            padding = last_row.repeat(n_audio_tokens - n_audio_features, 1)
                            audio_features = torch.cat([audio_features, padding], dim=0)
                            logger.debug(f"[TRACE] Padded audio_features to shape: {audio_features.shape}")
                        else:
                            audio_features = audio_features[:n_audio_tokens]
                            logger.debug(f"[TRACE] Truncated audio_features to shape: {audio_features.shape}")
                    else:
                        logger.debug(f"[TRACE] Audio features count matches, no adjustment needed")
                except Exception as e:
                    logger.error(f"[ERROR] Failed to adjust audio features count: {e}", exc_info=True)
                    raise

            with _TimingContext("merge_embeddings"):
                try:
                    logger.debug("[TRACE] Creating special_audio_mask")
                    special_audio_mask = (input_ids == self.config.audio_token_index)
                    logger.debug(f"[TRACE] special_audio_mask sum: {special_audio_mask.sum().item()}")
                    
                    logger.debug("[TRACE] Converting audio_features device and dtype")
                    audio_features = audio_features.to(device=inputs_embeds.device, dtype=inputs_embeds.dtype)
                    special_audio_mask = special_audio_mask.to(inputs_embeds.device)
                    special_audio_mask = special_audio_mask.unsqueeze(-1).expand_as(inputs_embeds)
                    logger.debug(f"[TRACE] Expanded special_audio_mask shape: {special_audio_mask.shape}")
                    
                    logger.debug("[TRACE] Calling masked_scatter")
                    inputs_embeds = inputs_embeds.masked_scatter(special_audio_mask, audio_features)
                    logger.debug(f"[TRACE] masked_scatter completed, inputs_embeds shape: {inputs_embeds.shape}")
                except Exception as e:
                    logger.error(f"[ERROR] Failed to merge embeddings: {e}", exc_info=True)
                    raise

            logger.debug(f"[TRACE] get_input_embeddings returning, shape: {inputs_embeds.shape}")
            return inputs_embeds

    def get_input_embeddings_v1(
        self,
        input_ids: torch.Tensor,
        multimodal_embeddings: Optional[MultiModalEmbeddings] = None,
    ) -> torch.Tensor:
        try:
            inputs_embeds = self.language_model.get_input_embeddings(input_ids)
        except Exception as e:
            logger.error(f"Failed to get language model input embeddings: {e}", exc_info=True)
            raise

        if multimodal_embeddings is not None and len(multimodal_embeddings) != 0:
            try:
                logger.debug(f"[TRACE V1] Processing multimodal_embeddings, len={len(multimodal_embeddings)}")
                audio_placeholder_mask = (input_ids == self.config.audio_token_index)
                num_audio_tokens = int(audio_placeholder_mask.sum().item())
                logger.debug(f"[TRACE V1] audio_token_index={self.config.audio_token_index}, num_audio_tokens in input_ids={num_audio_tokens}")

                if isinstance(multimodal_embeddings, torch.Tensor):
                    flattened_embeddings = multimodal_embeddings
                    logger.debug(f"[TRACE V1] multimodal_embeddings is Tensor, shape={flattened_embeddings.shape}")
                else:
                    embeddings_list: list[torch.Tensor] = []
                    for i, emb in enumerate(multimodal_embeddings):
                        if not isinstance(emb, torch.Tensor):
                            logger.warning(f"multimodal_embeddings item[{i}] is not a Tensor, skipping: {type(emb)}")
                            continue
                        logger.debug(f"[TRACE V1] multimodal_embeddings[{i}] shape={emb.shape}")
                        embeddings_list.append(emb)
                    if not embeddings_list:
                        raise ValueError("multimodal_embeddings is empty or does not contain valid Tensors.")
                    if len(embeddings_list) == 1:
                        flattened_embeddings = embeddings_list[0]
                    else:
                        flattened_embeddings = torch.cat(embeddings_list, dim=0)
                    logger.debug(f"[TRACE V1] flattened_embeddings shape={flattened_embeddings.shape}")

                total_audio_features = int(flattened_embeddings.shape[0])
                logger.debug(f"[TRACE V1] num_audio_tokens={num_audio_tokens}, total_audio_features={total_audio_features}")

                if num_audio_tokens != total_audio_features:
                    diff = num_audio_tokens - total_audio_features
                    logger.warning(f"[TRACE V1] Audio token count mismatch! num_audio_tokens={num_audio_tokens}, total_audio_features={total_audio_features}, diff={diff}")
                    if diff > 0:
                        last_row = flattened_embeddings[-1:, :].clone()
                        padding = last_row.repeat(diff, 1)
                        flattened_embeddings = torch.cat(
                            [flattened_embeddings, padding],
                            dim=0,
                        )
                    else:
                        flattened_embeddings = flattened_embeddings[:num_audio_tokens]

                adjusted_multimodal_embeddings: list[torch.Tensor] = [flattened_embeddings]

                # 检查音频embeddings质量
                logger.debug(f"[AUDIO_EMBEDDINGS] flattened shape={flattened_embeddings.shape}, mean={flattened_embeddings.mean().item():.6f}, std={flattened_embeddings.std().item():.6f}")
                
                inputs_embeds = merge_multimodal_embeddings(
                    input_ids,
                    inputs_embeds,
                    adjusted_multimodal_embeddings,
                    self.config.audio_token_index,
                )
                logger.debug(f"[MERGED_EMBEDDINGS] After merge: shape={inputs_embeds.shape}, mean={inputs_embeds.mean().item():.6f}, std={inputs_embeds.std().item():.6f}")
            except Exception as e:
                logger.error(f"merge_multimodal_embeddings failed: {e}", exc_info=True)
                raise

        return inputs_embeds

    def forward(
        self,
        input_ids: torch.Tensor,
        positions: torch.Tensor,
        intermediate_tensors: Optional[IntermediateTensors] = None,
        inputs_embeds: Optional[torch.Tensor] = None,
        **kwargs: object,
    ) -> Union[torch.Tensor, IntermediateTensors]:
        # logger.debug(f"[TRACE] ===== FORWARD ENTRY ===== input_ids shape: {input_ids.shape if input_ids is not None else None}")
        # logger.debug(f"[TRACE] positions shape: {positions.shape if positions is not None else None}")
        # logger.debug(f"[TRACE] intermediate_tensors is None: {intermediate_tensors is None}")
        # logger.debug(f"[TRACE] inputs_embeds is None: {inputs_embeds is None}")
        # logger.debug(f"[TRACE] kwargs keys: {list(kwargs.keys())}")
        
        if _PROFILE_AUDIO:
            cache_status = []
            if intermediate_tensors is not None:
                cache_status.append("intermediate_tensors(cached)")
            if inputs_embeds is not None:
                cache_status.append("inputs_embeds(cached)")
            if cache_status:
                print(f"[PERF] forward: Using cache - {', '.join(cache_status)}, skipping get_multimodal_embeddings", flush=True)
            else:
                print(f"[PERF] forward: No cache, will call get_multimodal_embeddings", flush=True)

        if intermediate_tensors is not None:
            # logger.debug("[TRACE] Using intermediate_tensors, setting inputs_embeds to None")
            inputs_embeds = None
        elif inputs_embeds is None:
            try:
                # logger.debug("[TRACE] Calling get_multimodal_embeddings from forward")
                multimodal_embeddings = self.get_multimodal_embeddings(**kwargs)
                # logger.debug(f"[TRACE] get_multimodal_embeddings returned, type: {type(multimodal_embeddings)}")

                # logger.debug("[TRACE] Calling get_input_embeddings from forward")
                inputs_embeds = self.get_input_embeddings(
                    input_ids,
                    multimodal_embeddings,
                )
                # logger.debug(f"[TRACE] get_input_embeddings returned, shape: {inputs_embeds.shape}")
                input_ids = None
                # logger.debug("[TRACE] Set input_ids to None after getting inputs_embeds")
            except Exception as e:
                logger.error(f"[ERROR] Failed to get multimodal embeddings or input embeddings: {e}", exc_info=True)
                raise
        else:
            logger.debug("[TRACE] Using provided inputs_embeds")

        try:
            logger.debug("[TRACE] Calling language_model.model")
            with _TimingContext("decoder_forward"):
                hidden_states = self.language_model.model(
                    input_ids,
                    positions,
                    intermediate_tensors,
                    inputs_embeds=inputs_embeds,
                )
            # logger.debug(f"[TRACE] language_model.model returned, type: {type(hidden_states)}")
            return hidden_states
        except Exception as e:
            logger.error(f"[ERROR] language_model.model call failed: {e}", exc_info=True)
            raise

    def compute_logits(
        self,
        hidden_states: torch.Tensor,
        sampling_metadata: SamplingMetadata,
    ) -> Optional[torch.Tensor]:
        logger.debug(f"[TRACE] compute_logits ENTRY, hidden_states shape: {hidden_states.shape if hasattr(hidden_states, 'shape') else type(hidden_states)}")
        try:
            with _TimingContext("decoder_compute_logits"):
                result = self.language_model.compute_logits(hidden_states, sampling_metadata)
            logger.debug(f"[TRACE] compute_logits returned, result shape: {result.shape if result is not None else None}")
            return result
        except Exception as e:
            logger.error(f"[ERROR] compute_logits failed: {e}", exc_info=True)
            raise

    def load_weights(self, weights: Iterable[tuple[str, torch.Tensor]]) -> set[str]:
        loader = AutoWeightsLoader(
            self,
            skip_substrs=[
                "positional_embedding.positional_embedding",
            ]
        )
        load_weights_set = loader.load_weights(weights)
        ignored_weights_set = {
            "audio_tower.conv2d1.weight",
            "audio_tower.conv2d1.bias",
            "audio_tower.conv2d2.weight",
            "audio_tower.conv2d2.bias",
            "audio_tower.conv2d3.weight",
            "audio_tower.conv2d3.bias",
        }
        load_weights_set = load_weights_set.union(ignored_weights_set)
        return load_weights_set
